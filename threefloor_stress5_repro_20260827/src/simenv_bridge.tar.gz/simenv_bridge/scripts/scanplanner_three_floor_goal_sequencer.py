#!/usr/bin/env python3
"""Run SCAN-Planner on F1/F2/F3 and hand stair ownership to RL managers.

The main-entrance step is crossed with the stair RL policy and a constrained
forward/yaw command.  Once the robot is physically clear of the threshold,
this node reloads the plane policy and gives the remaining flat-floor
waypoints to SCAN's manual-goal interface.  Every room has two complementary
camera/LiDAR scan poses.  Between floors it disables the flat-floor command mux, triggers the
appropriate physical stair manager, restores the plane policy on the upper
landing, and only then re-enables SCAN motion.
"""

import json
import math
import os
import threading
import time

import rospy
from geometry_msgs.msg import PoseStamped, Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import PointCloud2
from std_msgs.msg import Bool, Float32, String


def normalize_angle(angle):
    return math.atan2(math.sin(float(angle)), math.cos(float(angle)))


def accumulated_rotation(previous_yaw, current_yaw):
    return abs(normalize_angle(float(current_yaw) - float(previous_yaw)))


def attitude_loss_debounce(previous_since, upright_z, minimum_upright_z,
                           now, minimum_duration):
    if float(upright_z) >= float(minimum_upright_z):
        return None, False
    since = float(now) if previous_since is None else float(previous_since)
    return since, float(now) - since >= float(minimum_duration)


def is_room_scan_waypoint(waypoint, expected_rooms):
    note = str(waypoint.get("note", ""))
    # ``_center`` remains the immutable template fallback.  Run-local mission
    # configs replace every fallback with explicit scan_a/scan_b waypoints.
    if any(note == str(room) + "_center" for room in expected_rooms):
        return True
    if not bool(waypoint.get("scan", False)):
        return False
    return any(note in (str(room) + "_scan_a", str(room) + "_scan_b")
               for room in expected_rooms)


def waypoint_tolerance(note, default_tolerance=0.48,
                       room_tolerance=0.72, handoff_tolerance=0.55):
    text = str(note)
    if ((text.endswith("_scan_a") or text.endswith("_scan_b")) and
            "_room_" in text):
        return float(room_tolerance)
    if text.endswith("_handoff") or text.endswith("_stair_exit"):
        return float(handoff_tolerance)
    return float(default_tolerance)


def is_direct_entrance_waypoint(note):
    return str(note).startswith("main_entrance_")


def is_direct_plane_waypoint(waypoint):
    return str(waypoint.get("controller", "")) == "direct_plane_rl"


def is_direct_stair_waypoint(waypoint):
    return str(waypoint.get("controller", "")) == "direct_stair_rl"


def direct_rl_command(pose, target, maximum_speed, maximum_yaw_rate=0.35,
                      position_tolerance=0.48, target_yaw=None,
                      heading_tolerance=0.12,
                      minimum_forward_speed=0.18,
                      distance_gain=0.70):
    """Return a turn-before-forward command for the entrance step.

    SCAN correctly sees the apron as an obstacle, but its simultaneous
    lateral/yaw avoidance command destabilizes the learned gait on contact.
    The short entrance bridge uses the physical stair-RL policy with
    forward/yaw commands only; plane RL and SCAN take over inside the lobby.
    """
    dx = float(target[0]) - float(pose[0])
    dy = float(target[1]) - float(pose[1])
    distance = math.hypot(dx, dy)
    if distance <= float(position_tolerance):
        if target_yaw is None:
            return 0.0, 0.0, distance, True
        final_error = normalize_angle(float(target_yaw) - float(pose[3]))
        if abs(final_error) <= float(heading_tolerance):
            return 0.0, 0.0, distance, True
        yaw_rate = max(-float(maximum_yaw_rate), min(
            float(maximum_yaw_rate), 1.1 * final_error))
        return 0.0, yaw_rate, distance, False
    desired = math.atan2(dy, dx)
    error = normalize_angle(desired - float(pose[3]))
    yaw_rate = max(-float(maximum_yaw_rate), min(
        float(maximum_yaw_rate), 1.1 * error))
    forward = 0.0 if abs(error) > 0.16 else min(
        float(maximum_speed), max(
            float(minimum_forward_speed), float(distance_gain) * distance))
    return forward, yaw_rate, distance, False


def direct_entrance_rl_command(
        pose, target, target_yaw, maximum_speed, maximum_yaw_rate=0.35,
        position_tolerance=0.48, heading_tolerance=0.12,
        heading_release_tolerance=0.20, minimum_forward_speed=0.18,
        distance_gain=0.70, lateral_gain=0.60,
        maximum_lateral_speed=0.12):
    """Follow the main-entrance axis while correcting stochastic side drift.

    Pointing the robot directly at each waypoint is unsafe after a stair-gait
    stumble: lateral displacement rotates the requested heading away from the
    doorway and can leave the robot pivoting in place.  Entrance waypoints all
    carry the validated doorway yaw, so keep that heading invariant and use a
    small body-lateral command to remove cross-track error.  Translation is
    held until the heading is back inside a conservative release gate.
    """
    dx = float(target[0]) - float(pose[0])
    dy = float(target[1]) - float(pose[1])
    distance = math.hypot(dx, dy)
    heading_error = normalize_angle(float(target_yaw) - float(pose[3]))
    yaw_rate = max(-float(maximum_yaw_rate), min(
        float(maximum_yaw_rate), 1.1 * heading_error))

    if distance <= float(position_tolerance):
        reached = abs(heading_error) <= float(heading_tolerance)
        return 0.0, 0.0, (0.0 if reached else yaw_rate), distance, reached
    if abs(heading_error) > float(heading_release_tolerance):
        return 0.0, 0.0, yaw_rate, distance, False

    yaw = float(pose[3])
    forward_error = math.cos(yaw) * dx + math.sin(yaw) * dy
    lateral_error = -math.sin(yaw) * dx + math.cos(yaw) * dy
    forward = 0.0
    if forward_error > 0.02:
        forward = min(float(maximum_speed), max(
            float(minimum_forward_speed),
            float(distance_gain) * forward_error))
    lateral = max(-float(maximum_lateral_speed), min(
        float(maximum_lateral_speed), float(lateral_gain) * lateral_error))
    return forward, lateral, yaw_rate, distance, False


def policy_kind(value):
    text = str(value).lower()
    if "stair" in text:
        return "stair"
    if "plane" in text or "flat" in text:
        return "plane"
    return "unknown"


def load_config(path):
    with open(path, "r", encoding="utf-8") as stream:
        config = json.load(stream)
    if config.get("schema") != "scanplanner_three_floor_rl_mission_v1":
        raise ValueError("unsupported mission config schema")
    floors = config.get("floors", [])
    if [floor.get("floor_number") for floor in floors] != [1, 2, 3]:
        raise ValueError("mission config must contain floors 1, 2, and 3")
    return config


def atomic_write_json(path, payload):
    directory = os.path.dirname(os.path.abspath(path))
    os.makedirs(directory, exist_ok=True)
    temporary = path + ".tmp"
    with open(temporary, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, indent=2, sort_keys=True)
        stream.write("\n")
    os.replace(temporary, path)


class ThreeFloorGoalSequencer:
    MANAGER_TOPICS = (
        "/simenv/stair_transition_state",
        "/simenv/second_to_third_floor_stair_state",
        "/simenv/third_to_first_floor_stair_state",
    )

    def __init__(self):
        self._config_path = rospy.get_param(
            "~mission_config",
            "/workspace/SimEnv/src/simenv_bridge/config/three_floor_rl_mission.json",
        )
        self._output_dir = rospy.get_param(
            "~output_dir", "/workspace/SimEnv/results/scanplanner_three_floor_rl")
        self._config = load_config(self._config_path)
        self._plane_policy = str(self._config["runtime"]["plane_policy"])
        self._stair_policy = str(self._config["runtime"]["stair_policy"])
        self._goal_tolerance = float(rospy.get_param("~goal_tolerance", 0.48))
        self._room_tolerance = float(rospy.get_param("~room_tolerance", 0.72))
        self._handoff_tolerance = float(
            rospy.get_param("~handoff_tolerance", 0.55))
        self._floor_height_tolerance = float(
            rospy.get_param("~floor_height_tolerance", 0.85))
        self._nominal_body_height = float(
            rospy.get_param("~nominal_body_height", 0.34))
        self._waypoint_timeout = float(
            rospy.get_param("~waypoint_timeout_sec", 150.0))
        self._progress_timeout = float(
            rospy.get_param("~progress_timeout_sec", 45.0))
        self._progress_distance = float(
            rospy.get_param("~progress_distance_m", 0.08))
        self._maximum_replans = int(rospy.get_param("~maximum_replans", 2))
        self._policy_timeout = float(
            rospy.get_param("~policy_timeout_sec", 35.0))
        self._handoff_timeout = float(
            rospy.get_param("~handoff_timeout_sec", 90.0))
        self._startup_timeout = float(
            rospy.get_param("~startup_timeout_sec", 240.0))
        self._scan_turn = float(rospy.get_param("~room_scan_turn_rad", 2.0 * math.pi))
        self._scan_yaw_rate = float(rospy.get_param("~room_scan_yaw_rate", 0.45))
        self._scan_timeout = float(rospy.get_param("~room_scan_timeout_sec", 40.0))
        self._room_scan_settle = max(
            0.0, float(rospy.get_param("~room_scan_settle_sec", 0.5)))
        self._rate_hz = max(2.0, float(rospy.get_param("~rate", 10.0)))
        self._stage_announcement_hold = max(
            0.0, float(rospy.get_param(
                "~stage_announcement_hold_sec", 0.5)))
        self._floor_control_settle = max(
            0.0, float(rospy.get_param("~floor_control_settle_sec", 0.5)))
        self._manager_release_settle = max(
            0.0, float(rospy.get_param("~manager_release_settle_sec", 0.7)))
        self._minimum_upright_z = float(
            rospy.get_param("~minimum_upright_z", 0.55))
        self._minimum_upright_duration = max(
            0.0, float(rospy.get_param(
                "~minimum_upright_duration_sec", 0.60)))
        self._speed_scale = max(0.1, float(rospy.get_param("~speed_scale", 1.0)))
        self._entrance_speed_scale = max(
            0.1, float(rospy.get_param(
                "~entrance_speed_scale", self._speed_scale)))
        self._maximum_floor_speed = max(
            0.05, float(rospy.get_param("~maximum_floor_speed", 1.0)))
        self._direct_plane_yaw_rate = max(
            0.1, float(rospy.get_param("~direct_plane_yaw_rate", 0.55)))
        self._direct_plane_min_speed = max(
            0.18, float(rospy.get_param(
                "~direct_plane_min_forward_speed", 0.30)))
        self._direct_plane_distance_gain = max(
            0.70, float(rospy.get_param(
                "~direct_plane_distance_gain", 1.10)))
        self._direct_stair_yaw_rate = max(
            0.1, float(rospy.get_param("~direct_stair_yaw_rate", 0.35)))
        self._entrance_heading_release = max(
            0.05, float(rospy.get_param(
                "~entrance_fixed_heading_release_rad", 0.20)))
        self._entrance_lateral_gain = max(
            0.0, float(rospy.get_param("~entrance_lateral_gain", 0.60)))
        self._entrance_max_lateral_speed = max(
            0.0, float(rospy.get_param(
                "~entrance_max_lateral_speed_mps", 0.12)))
        self._entrance_progress_timeout = max(
            2.0, float(rospy.get_param(
                "~entrance_progress_timeout_sec", 5.0)))
        self._entrance_recovery_hold = max(
            0.0, float(rospy.get_param(
                "~entrance_recovery_hold_sec", 1.0)))
        self._entrance_recovery_max_attempts = max(
            0, int(rospy.get_param(
                "~entrance_recovery_max_attempts", 2)))
        self._plane_fast_takeover = bool(rospy.get_param(
            "~plane_fast_takeover", True))
        self._plane_fast_blend = max(
            0.25, float(rospy.get_param(
                "~plane_fast_takeover_blend_seconds", 1.25)))
        self._plane_fast_zero_hold = max(
            0.10, float(rospy.get_param(
                "~plane_fast_takeover_zero_hold_seconds", 0.75)))
        timing = self._config.get("task_timing", {})
        self._mission_budget = float(
            timing.get("maximum_exploration_duration_sec", 600.0))

        os.makedirs(self._output_dir, exist_ok=True)
        self._lock = threading.RLock()
        self._write_lock = threading.Lock()
        self._pose = None
        self._ready = False
        self._ready_at = None
        self._cloud_seen = False
        self._camera_ready = False
        self._exploration_clock_ready = False
        self._policy_ack_at = {"plane": None, "stair": None}
        self._manager_states = {}
        self._floor_control_enabled = False
        self._failure = None
        self._started_wall_time = time.time()
        self._exploration_started_monotonic = None
        self._events = []
        self._attitude_lost_since = None

        self._goal_pub = rospy.Publisher(
            "/move_base_simple/goal", PoseStamped, queue_size=1, latch=True)
        self._scan_active_pub = rospy.Publisher(
            "/scanplanner/scan_active", Bool, queue_size=1, latch=True)
        self._room_scan_active_pub = rospy.Publisher(
            "/scanplanner/room_scan_active", Bool, queue_size=1, latch=True)
        self._scan_cmd_pub = rospy.Publisher(
            "/scanplanner/scan_cmd_vel", Twist, queue_size=2)
        self._floor_enable_pub = rospy.Publisher(
            "/scanplanner/floor_control_enabled", Bool, queue_size=1, latch=True)
        self._speed_pub = rospy.Publisher(
            "/scanplanner/floor_speed_limit", Float32, queue_size=1, latch=True)
        self._route_state_pub = rospy.Publisher(
            "/scanplanner/route_state", String, queue_size=1, latch=True)
        self._complete_pub = rospy.Publisher(
            "/scanplanner/route_complete", Bool, queue_size=1, latch=True)
        self._failed_pub = rospy.Publisher(
            "/scanplanner/route_failed", Bool, queue_size=1, latch=True)
        self._exploration_active_pub = rospy.Publisher(
            "/simenv/exploration_active", Bool, queue_size=1, latch=True)
        self._policy_pub = rospy.Publisher(
            "/simenv/rl_policy_request", String, queue_size=1, latch=True)
        self._baseline_state_pub = rospy.Publisher(
            "/simenv/baseline_state", String, queue_size=1, latch=True)
        self._second_state_pub = rospy.Publisher(
            "/simenv/second_floor_state", String, queue_size=1, latch=True)
        self._third_state_pub = rospy.Publisher(
            "/simenv/third_floor_state", String, queue_size=1, latch=True)

        rospy.Subscriber(
            "/Odometry_gazebo", Odometry, self._on_odom, queue_size=20)
        rospy.Subscriber(
            "/registered_scan", PointCloud2, self._on_cloud, queue_size=1)
        rospy.Subscriber(
            "/locomotion_ready", Bool, self._on_ready, queue_size=5)
        rospy.Subscriber(
            "/simenv/recording_camera_ready", Bool,
            self._on_camera_ready, queue_size=2)
        rospy.Subscriber(
            "/simenv/exploration_clock_ready", Bool,
            self._on_exploration_clock_ready, queue_size=2)
        rospy.Subscriber(
            "/rl_takeover_status", String, self._on_policy_status, queue_size=10)
        rospy.Subscriber(
            "/simenv/mission_abort", Bool, self._on_mission_abort, queue_size=2)
        for topic in self.MANAGER_TOPICS:
            rospy.Subscriber(
                topic, String, self._on_manager_state,
                callback_args=topic, queue_size=10)

        self._floor_enable_pub.publish(Bool(data=False))
        self._scan_active_pub.publish(Bool(data=False))
        self._room_scan_active_pub.publish(Bool(data=False))
        self._complete_pub.publish(Bool(data=False))
        self._failed_pub.publish(Bool(data=False))
        self._exploration_active_pub.publish(Bool(data=False))
        self._record_event("sequencer_started", config=self._config_path)
        rospy.on_shutdown(self._on_shutdown)

    def _record_event(self, event, **fields):
        payload = {"event": str(event), "wall_time": round(time.time(), 3)}
        payload.update(fields)
        with self._lock:
            self._events.append(payload)
            self._events = self._events[-1000:]

    def _publish_route_state(self, phase, **fields):
        payload = {"phase": str(phase), "wall_time": round(time.time(), 3)}
        payload.update(fields)
        self._route_state_pub.publish(
            String(data=json.dumps(payload, sort_keys=True)))
        self._record_event("route_state", **payload)

    def _on_odom(self, message):
        position = message.pose.pose.position
        orientation = message.pose.pose.orientation
        yaw = math.atan2(
            2.0 * (orientation.w * orientation.z +
                   orientation.x * orientation.y),
            1.0 - 2.0 * (orientation.y * orientation.y +
                         orientation.z * orientation.z),
        )
        with self._lock:
            self._pose = (float(position.x), float(position.y),
                          float(position.z), float(yaw))
            upright_z = 1.0 - 2.0 * (
                float(orientation.x) ** 2 + float(orientation.y) ** 2)
            guard_active = (self._exploration_started_monotonic is not None and
                            self._floor_control_enabled)
            if guard_active and upright_z < self._minimum_upright_z:
                now = time.monotonic()
                self._attitude_lost_since, attitude_lost = (
                    attitude_loss_debounce(
                        self._attitude_lost_since, upright_z,
                        self._minimum_upright_z, now,
                        self._minimum_upright_duration))
                if attitude_lost and self._failure is None:
                    self._failure = (
                        "owned_rl_attitude_lost_upright_z_{:.3f}".format(
                            upright_z))
            else:
                self._attitude_lost_since = None

    def _on_cloud(self, _message):
        with self._lock:
            self._cloud_seen = True

    def _on_mission_abort(self, message):
        if not bool(message.data):
            return
        with self._lock:
            if self._failure is None:
                self._failure = "mission_aborted_by_supervisor"

    def _deadline_ok(self):
        with self._lock:
            started = self._exploration_started_monotonic
            failure = self._failure
        if failure:
            return False
        if started is None:
            return True
        if time.monotonic() - started < self._mission_budget:
            return True
        with self._lock:
            if self._failure is None:
                self._failure = "exploration_deadline_exceeded_{:.1f}s".format(
                    self._mission_budget)
        return False

    def _on_ready(self, message):
        with self._lock:
            self._ready = bool(message.data)
            if message.data:
                self._ready_at = time.monotonic()

    def _on_camera_ready(self, message):
        with self._lock:
            self._camera_ready = bool(message.data)

    def _on_exploration_clock_ready(self, message):
        with self._lock:
            self._exploration_clock_ready = bool(message.data)

    def _on_policy_status(self, message):
        text = str(message.data)
        now = time.monotonic()
        kind = policy_kind(text)
        expected_path = {
            "plane": self._plane_policy,
            "stair": self._stair_policy,
        }.get(kind)
        if ("policy_reloaded:" in text and expected_path and
                os.path.basename(expected_path) in text):
            with self._lock:
                self._policy_ack_at[kind] = now
        if "policy_reload_failed:" in text:
            with self._lock:
                self._failure = "policy_reload_failed:{}".format(text)
        self._record_event("policy_status", status=text,
                           policy=policy_kind(text))

    def _on_manager_state(self, message, topic):
        text = str(message.data).strip()
        with self._lock:
            self._manager_states[topic] = text
            terminal_failure = (
                "FAILED", "TIMEOUT", "FALL_DETECTED", "ALIGNMENT_LOST",
                "ATTITUDE_LOST")
            if any(token in text.upper() for token in terminal_failure):
                self._failure = "stair_manager_failure:{}:{}".format(topic, text)
        self._record_event("stair_state", topic=topic, state=text)

    def _sleep(self, seconds):
        deadline = time.monotonic() + max(0.0, float(seconds))
        while not rospy.is_shutdown() and time.monotonic() < deadline:
            if not self._deadline_ok():
                return
            time.sleep(min(1.0 / self._rate_hz,
                           max(0.0, deadline - time.monotonic())))

    def _wait(self, predicate, timeout, failure_reason):
        deadline = time.monotonic() + float(timeout)
        while not rospy.is_shutdown() and time.monotonic() < deadline:
            if not self._deadline_ok():
                return False
            with self._lock:
                failure = self._failure
            if failure:
                return False
            if predicate():
                return True
            time.sleep(1.0 / self._rate_hz)
        with self._lock:
            if self._failure is None:
                self._failure = str(failure_reason)
        return False

    def _wait_for_startup(self):
        self._publish_route_state("WAIT_PLANE_RL_AND_SCANPLANNER")

        def ready():
            with self._lock:
                return (self._pose is not None and self._ready and
                        self._cloud_seen and self._camera_ready and
                        self._goal_pub.get_num_connections() > 0)

        return self._wait(
            ready, self._startup_timeout,
            "startup_timeout_waiting_for_plane_rl_scan_camera_or_scanplanner")

    def _clock_acknowledged(self):
        with self._lock:
            return self._exploration_clock_ready

    def _set_floor_enabled(self, enabled):
        if not enabled:
            self._publish_scan(False)
        with self._lock:
            self._floor_control_enabled = bool(enabled)
        self._floor_enable_pub.publish(Bool(data=bool(enabled)))
        self._record_event("floor_control", enabled=bool(enabled))
        self._sleep(self._floor_control_settle)

    def _arm_plane_fast_takeover(self):
        """Arm the controller's one-shot flat-policy handoff profile.

        Every plane reload occurs with zero command on a level apron or
        landing.  The shorter blend/hold is therefore restricted to plane
        policies and is enabled last so the controller never observes a
        partially written profile.
        """
        if not self._plane_fast_takeover:
            return
        rospy.set_param(
            "/simenv/plane_fast_takeover_blend_seconds",
            self._plane_fast_blend)
        rospy.set_param(
            "/simenv/plane_fast_takeover_zero_hold_seconds",
            self._plane_fast_zero_hold)
        rospy.set_param("/simenv/plane_fast_takeover_enabled", True)

    def _switch_rl_policy(self, policy, expected_kind, route_phase,
                          floor_number, failure_reason):
        """Reload one gait and require fresh reload plus readiness evidence."""
        expected_kind = str(expected_kind)
        if expected_kind not in self._policy_ack_at:
            raise ValueError("unsupported RL policy kind: {}".format(expected_kind))
        self._publish_scan(False)
        request_at = time.monotonic()
        with self._lock:
            self._policy_ack_at[expected_kind] = None
            self._ready_at = None
        self._publish_route_state(
            route_phase, floor=int(floor_number), policy=str(policy),
            expected_policy_kind=expected_kind)
        if expected_kind == "plane":
            self._arm_plane_fast_takeover()
        deadline = time.monotonic() + self._policy_timeout
        next_request = 0.0
        while not rospy.is_shutdown() and time.monotonic() < deadline:
            if not self._deadline_ok():
                return False
            now = time.monotonic()
            if now >= next_request:
                self._policy_pub.publish(String(data=str(policy)))
                next_request = now + 0.75
            with self._lock:
                ack_at = self._policy_ack_at[expected_kind]
                ready_at = self._ready_at
                ready = self._ready
                failure = self._failure
            if failure:
                return False
            if (ack_at is not None and ack_at >= request_at and ready and
                    ready_at is not None and ready_at >= request_at):
                self._record_event(
                    "rl_policy_switch_ready", floor=int(floor_number),
                    policy=str(policy), policy_kind=expected_kind)
                return True
            time.sleep(1.0 / self._rate_hz)
        with self._lock:
            if self._failure is None:
                self._failure = str(failure_reason)
        return False

    def _publish_goal(self, waypoint):
        message = PoseStamped()
        message.header.stamp = rospy.Time.now()
        message.header.frame_id = "map"
        message.pose.position.x = float(waypoint["x"])
        message.pose.position.y = float(waypoint["y"])
        message.pose.position.z = float(waypoint.get("z", 0.0))
        half_yaw = 0.5 * float(waypoint.get("yaw", 0.0))
        message.pose.orientation.z = math.sin(half_yaw)
        message.pose.orientation.w = math.cos(half_yaw)
        self._goal_pub.publish(message)

    def _publish_scan(self, active, yaw_rate=0.0, forward=0.0, lateral=0.0):
        self._scan_active_pub.publish(Bool(data=bool(active)))
        command = Twist()
        command.linear.x = float(forward) if active else 0.0
        command.linear.y = float(lateral) if active else 0.0
        command.angular.z = float(yaw_rate) if active else 0.0
        self._scan_cmd_pub.publish(command)

    def _publish_room_scan_active(self, active):
        self._room_scan_active_pub.publish(Bool(data=bool(active)))

    def _drive_direct_waypoint(self, floor, waypoint, effective_speed,
                               tolerance, index, policy_kind_name):
        target = (float(waypoint["x"]), float(waypoint["y"]))
        note = str(waypoint["note"])
        target_yaw = (float(waypoint.get("yaw", 0.0))
                      if bool(waypoint.get("align_yaw", False)) else None)
        maximum_yaw_rate = float(waypoint.get(
            "alignment_yaw_rate",
            self._direct_stair_yaw_rate if policy_kind_name == "stair"
            else self._direct_plane_yaw_rate))
        heading_tolerance = float(waypoint.get(
            "heading_tolerance", 0.12))
        entrance_mode = is_direct_entrance_waypoint(note)
        entrance_yaw = float(waypoint.get("yaw", math.pi / 2.0))
        deadline = time.monotonic() + self._waypoint_timeout
        progress_timeout = (
            self._entrance_progress_timeout
            if entrance_mode else self._progress_timeout)
        progress_deadline = time.monotonic() + progress_timeout
        best_distance = float("inf")
        best_heading_error = float("inf")
        stall_recoveries = 0
        distance = float("inf")
        self._publish_route_state(
            "NAVIGATE_DIRECT_{}_RL".format(policy_kind_name.upper()),
            floor=int(floor["floor_number"]),
            waypoint_index=index, waypoint=note, target=list(target),
            forward_only=not entrance_mode,
            control_mode=(
                "fixed_entrance_heading_with_lateral_correction"
                if entrance_mode else "turn_before_forward"))
        while not rospy.is_shutdown() and time.monotonic() < deadline:
            if not self._deadline_ok():
                break
            with self._lock:
                pose = self._pose
                ready = self._ready
                failure = self._failure
            if failure:
                break
            if pose is None or not ready:
                self._publish_scan(False)
                time.sleep(1.0 / self._rate_hz)
                continue
            lateral = 0.0
            if entrance_mode:
                forward, lateral, yaw_rate, distance, reached = (
                    direct_entrance_rl_command(
                        pose, target, entrance_yaw, effective_speed,
                        maximum_yaw_rate=maximum_yaw_rate,
                        position_tolerance=tolerance,
                        heading_tolerance=heading_tolerance,
                        heading_release_tolerance=self._entrance_heading_release,
                        minimum_forward_speed=0.18,
                        distance_gain=0.70,
                        lateral_gain=self._entrance_lateral_gain,
                        maximum_lateral_speed=self._entrance_max_lateral_speed))
                heading_error = abs(normalize_angle(entrance_yaw - pose[3]))
            else:
                forward, yaw_rate, distance, reached = direct_rl_command(
                    pose, target, effective_speed,
                    maximum_yaw_rate=maximum_yaw_rate,
                    position_tolerance=tolerance,
                    target_yaw=target_yaw,
                    heading_tolerance=heading_tolerance,
                    minimum_forward_speed=(
                        self._direct_plane_min_speed
                        if policy_kind_name == "plane" else 0.18),
                    distance_gain=(
                        self._direct_plane_distance_gain
                        if policy_kind_name == "plane" else 0.70))
                heading_error = float("inf")
            if reached:
                self._publish_scan(False)
                return pose, distance, stall_recoveries
            self._publish_scan(True, yaw_rate, forward, lateral)
            distance_progress = distance <= best_distance - self._progress_distance
            heading_progress = (
                entrance_mode and
                heading_error <= best_heading_error - 0.08)
            if distance_progress or heading_progress:
                best_distance = distance
                best_heading_error = heading_error
                progress_deadline = time.monotonic() + progress_timeout
            elif time.monotonic() >= progress_deadline:
                if (entrance_mode and stall_recoveries <
                        self._entrance_recovery_max_attempts):
                    stall_recoveries += 1
                    self._publish_scan(False)
                    self._record_event(
                        "entrance_stall_recovery", floor=int(floor["floor_number"]),
                        waypoint=note, attempt=stall_recoveries,
                        pose=[round(value, 4) for value in pose],
                        distance_m=round(distance, 4),
                        heading_error_rad=round(heading_error, 4),
                        zero_hold_sec=self._entrance_recovery_hold)
                    self._publish_route_state(
                        "RECOVER_ENTRANCE_STALL",
                        floor=int(floor["floor_number"]), waypoint=note,
                        attempt=stall_recoveries,
                        distance_m=round(distance, 4),
                        heading_error_rad=round(heading_error, 4))
                    self._sleep(self._entrance_recovery_hold)
                    best_distance = distance
                    best_heading_error = heading_error
                    progress_deadline = time.monotonic() + progress_timeout
                    continue
                with self._lock:
                    if self._failure is None:
                        self._failure = "direct_rl_no_progress:{}".format(note)
                break
            time.sleep(1.0 / self._rate_hz)
        self._publish_scan(False)
        return None, distance, stall_recoveries

    def _scan_room(self, floor_number, waypoint):
        note = str(waypoint["note"])
        scan_turn = float(waypoint.get("scan_turn_rad", self._scan_turn))
        scan_yaw_rate = float(
            waypoint.get("scan_yaw_rate", self._scan_yaw_rate))
        scan_timeout = float(
            waypoint.get("scan_timeout_sec", self._scan_timeout))
        scan_settle = max(0.0, float(
            waypoint.get("scan_settle_sec", self._room_scan_settle)))
        pause_interval = max(0.0, float(
            waypoint.get("scan_pause_interval_rad", 0.0)))
        pause_dwell = max(0.0, float(
            waypoint.get("scan_pause_dwell_sec", 0.0)))
        with self._lock:
            if self._pose is None:
                return False, 0.0
            previous_yaw = self._pose[3]
        total = 0.0
        next_pause = pause_interval if pause_interval > 0.0 else None
        pause_count = 0
        deadline = time.monotonic() + scan_timeout
        progress_deadline = time.monotonic() + min(8.0, scan_timeout)
        self._publish_route_state(
            "SCAN_ROOM", floor=floor_number, waypoint=note,
            target_rotation_rad=scan_turn, yaw_rate_rad_s=scan_yaw_rate)
        self._publish_room_scan_active(True)
        while not rospy.is_shutdown() and time.monotonic() < deadline:
            if not self._deadline_ok():
                self._publish_scan(False)
                self._publish_room_scan_active(False)
                return False, total
            with self._lock:
                pose = self._pose
                ready = self._ready
                failure = self._failure
            if failure or not ready or pose is None:
                self._publish_scan(False)
                self._publish_room_scan_active(False)
                return False, total
            increment = accumulated_rotation(previous_yaw, pose[3])
            if increment > 0.002:
                total += increment
                previous_yaw = pose[3]
                progress_deadline = time.monotonic() + 8.0
            if (next_pause is not None and total >= next_pause and
                    next_pause <= scan_turn - 0.30):
                self._publish_scan(True, 0.0)
                pause_count += 1
                self._record_event(
                    "room_scan_observation_pause", floor=floor_number,
                    waypoint=note, pause_index=pause_count,
                    rotation_rad=round(total, 3),
                    dwell_sec=round(pause_dwell, 3))
                self._sleep(pause_dwell)
                next_pause += pause_interval
                progress_deadline = time.monotonic() + 8.0
                continue
            self._publish_scan(True, scan_yaw_rate)
            if total >= scan_turn - 0.08:
                # Preserve the already budgeted settle as a real stationary
                # observation window.  final-v5 seed 3 exposed a red sphere
                # with two valid frames while the old code disabled detection
                # before sleeping here, leaving it one frame short of the
                # three-frame confirmation threshold.
                self._publish_scan(True, 0.0)
                if scan_settle > 0.0:
                    self._record_event(
                        "room_scan_final_observation_dwell",
                        floor=floor_number, waypoint=note,
                        rotation_rad=round(total, 3),
                        dwell_sec=round(scan_settle, 3))
                    self._sleep(scan_settle)
                self._publish_scan(False)
                self._publish_room_scan_active(False)
                self._record_event(
                    "room_scan_complete", floor=floor_number,
                    waypoint=note, rotation_rad=round(total, 3),
                    target_rotation_rad=round(scan_turn, 3),
                    yaw_rate_rad_s=round(scan_yaw_rate, 3),
                    observation_pauses=pause_count,
                    final_observation_dwell_sec=round(scan_settle, 3))
                return True, total
            if time.monotonic() >= progress_deadline:
                break
            time.sleep(1.0 / self._rate_hz)
        self._publish_scan(False)
        self._publish_room_scan_active(False)
        with self._lock:
            if self._failure is None:
                self._failure = "room_scan_timeout:{}".format(note)
        return False, total

    def _tour_path(self, floor_number):
        if int(floor_number) == 1:
            return os.path.join(self._output_dir, "tour_summary.json")
        directory = "second_floor" if int(floor_number) == 2 else "third_floor"
        return os.path.join(self._output_dir, directory, "tour_summary.json")

    def _write_tour(self, floor, records, status, reason=None):
        successful = status == "completed"
        payload = {
            "schema": "scanplanner_floor_tour_v1",
            "planner": "SCAN-Planner",
            "motion_backend": "plane_rl",
            "policy": self._plane_policy,
            "entrance_motion_backend": (
                "stair_rl" if int(floor["floor_number"]) == 1 else None),
            "entrance_policy": (
                self._stair_policy if int(floor["floor_number"]) == 1 else None),
            "floor_number": int(floor["floor_number"]),
            "floor_index": int(floor["floor_index"]),
            "floor_z": float(floor["z"]),
            "status": str(status),
            "success": successful,
            "termination_reason": (
                "SCANPLANNER_FLOOR_COMPLETE" if successful else str(reason)),
            "expected_rooms": list(floor["expected_rooms"]),
            "waypoints_planned": len(floor["waypoints"]),
            "waypoints": list(records),
            "started_wall_time": round(self._started_wall_time, 3),
            "updated_wall_time": round(time.time(), 3),
        }
        with self._write_lock:
            atomic_write_json(self._tour_path(floor["floor_number"]), payload)

    def _run_floor(self, floor):
        floor_number = int(floor["floor_number"])
        entrance_stair_active = floor_number == 1
        records = []
        self._write_tour(floor, records, "running")
        self._set_floor_enabled(True)
        descent_handoff_stair_active = False
        if not entrance_stair_active:
            self._publish_route_state("EXPLORE_FLOOR", floor=floor_number)
            self._sleep(self._stage_announcement_hold)

        for index, waypoint in enumerate(floor["waypoints"]):
            note = str(waypoint["note"])
            if entrance_stair_active and not is_direct_entrance_waypoint(note):
                self._set_floor_enabled(False)
                if not self._switch_rl_policy(
                        self._plane_policy, "plane",
                        "RESTORE_PLANE_RL_AFTER_ENTRANCE", floor_number,
                        "plane_policy_restore_timeout_after_main_entrance"):
                    with self._lock:
                        reason = self._failure
                    self._write_tour(floor, records, "failed", reason)
                    return False
                entrance_stair_active = False
                self._set_floor_enabled(True)
                self._publish_route_state("EXPLORE_FLOOR", floor=floor_number)
                self._sleep(self._stage_announcement_hold)
            if (is_direct_stair_waypoint(waypoint) and
                    not descent_handoff_stair_active):
                self._set_floor_enabled(False)
                if not self._switch_rl_policy(
                        self._stair_policy, "stair",
                        "PREPARE_DESCENT_THRESHOLD_STAIR_RL", floor_number,
                        "stair_policy_switch_timeout_before_descent_handoff"):
                    with self._lock:
                        reason = self._failure
                    self._write_tour(floor, records, "failed", reason)
                    return False
                descent_handoff_stair_active = True
                self._set_floor_enabled(True)
                self._publish_route_state(
                    "ENTER_DESCENT_THRESHOLD_STAIR_RL", floor=floor_number,
                    waypoint=note)
                self._sleep(self._stage_announcement_hold)
            tolerance = float(waypoint.get(
                "tolerance", waypoint_tolerance(
                    note, self._goal_tolerance, self._room_tolerance,
                    self._handoff_tolerance)))
            target = (float(waypoint["x"]), float(waypoint["y"]))
            waypoint_speed_scale = (
                self._entrance_speed_scale
                if (is_direct_entrance_waypoint(note) or
                    is_direct_stair_waypoint(waypoint))
                else self._speed_scale)
            effective_speed = min(
                self._maximum_floor_speed,
                waypoint_speed_scale * float(waypoint["speed"]),
            )
            self._speed_pub.publish(Float32(data=effective_speed))
            direct_policy_kind = None
            if (is_direct_entrance_waypoint(note) or
                    is_direct_stair_waypoint(waypoint)):
                direct_policy_kind = "stair"
            elif is_direct_plane_waypoint(waypoint):
                direct_policy_kind = "plane"
            if direct_policy_kind is not None:
                direct_policy = (
                    self._stair_policy if direct_policy_kind == "stair"
                    else self._plane_policy)
                direct_controller = "direct_forward_{}_rl".format(
                    direct_policy_kind)
                started = time.monotonic()
                reached_pose, distance, stall_recoveries = self._drive_direct_waypoint(
                    floor, waypoint, effective_speed, tolerance, index,
                    direct_policy_kind)
                if reached_pose is None:
                    with self._lock:
                        if self._failure is None:
                            self._failure = "direct_rl_timeout:{}".format(note)
                        reason = self._failure
                    records.append({
                        "index": index,
                        "note": note,
                        "target": [target[0], target[1], float(waypoint["z"])],
                        "success": False,
                        "distance_error_m": (
                            round(distance, 4) if math.isfinite(distance) else None),
                        "replans": 0,
                        "stall_recoveries": int(stall_recoveries),
                        "controller": direct_controller,
                        "policy": direct_policy,
                    })
                    self._write_tour(floor, records, "failed", reason)
                    return False
                scan_completed = False
                scan_rotation = 0.0
                if is_room_scan_waypoint(waypoint, floor["expected_rooms"]):
                    scan_completed, scan_rotation = self._scan_room(
                        floor_number, waypoint)
                    if not scan_completed:
                        records.append({
                            "index": index,
                            "note": note,
                            "target": [
                                target[0], target[1], float(waypoint["z"])],
                            "success": False,
                            "scan_completed": False,
                            "scan_rotation_rad": round(scan_rotation, 3),
                            "reached_pose": [
                                round(value, 4) for value in reached_pose],
                            "distance_error_m": round(distance, 4),
                            "replans": 0,
                            "controller": direct_controller,
                            "policy": direct_policy,
                        })
                        with self._lock:
                            reason = self._failure
                        self._write_tour(floor, records, "failed", reason)
                        return False
                record = {
                    "index": index,
                    "note": note,
                    "target": [target[0], target[1], float(waypoint["z"])],
                    "success": True,
                    "scan_completed": scan_completed,
                    "scan_rotation_rad": round(scan_rotation, 3),
                    "reached_pose": [round(value, 4) for value in reached_pose],
                    "distance_error_m": round(distance, 4),
                    "replans": 0,
                    "stall_recoveries": int(stall_recoveries),
                    "controller": direct_controller,
                    "policy": direct_policy,
                    "effective_speed_limit_mps": round(effective_speed, 3),
                    "elapsed_sec": round(time.monotonic() - started, 3),
                    "wall_time": round(time.time(), 3),
                }
                records.append(record)
                self._sleep(max(0.0, float(
                    waypoint.get("post_reach_settle_sec", 0.0))))
                self._record_event(
                    "waypoint_reached", floor=floor_number, waypoint=note,
                    distance_m=record["distance_error_m"],
                    controller=record["controller"],
                    scan_completed=scan_completed)
                self._write_tour(floor, records, "running")
                continue
            self._publish_goal(waypoint)
            self._publish_route_state(
                "NAVIGATE_SCANPLANNER", floor=floor_number,
                waypoint_index=index, waypoint=note, target=list(target))
            started = time.monotonic()
            hard_deadline = started + self._waypoint_timeout
            progress_deadline = started + self._progress_timeout
            best_distance = float("inf")
            replans = 0
            reached_pose = None
            distance = float("inf")
            while not rospy.is_shutdown() and time.monotonic() < hard_deadline:
                if not self._deadline_ok():
                    break
                with self._lock:
                    pose = self._pose
                    ready = self._ready
                    failure = self._failure
                if failure:
                    break
                if pose is None or not ready:
                    time.sleep(1.0 / self._rate_hz)
                    continue
                distance = math.hypot(pose[0] - target[0], pose[1] - target[1])
                expected_body_z = float(floor["z"]) + self._nominal_body_height
                height_ok = abs(pose[2] - expected_body_z) <= self._floor_height_tolerance
                if distance <= tolerance and height_ok:
                    reached_pose = pose
                    break
                if distance <= best_distance - self._progress_distance:
                    best_distance = distance
                    progress_deadline = time.monotonic() + self._progress_timeout
                elif time.monotonic() >= progress_deadline:
                    if replans < self._maximum_replans:
                        replans += 1
                        best_distance = distance
                        progress_deadline = time.monotonic() + self._progress_timeout
                        self._publish_goal(waypoint)
                        self._record_event(
                            "scanplanner_goal_reissued", floor=floor_number,
                            waypoint=note, attempt=replans,
                            distance_m=round(distance, 3))
                    else:
                        with self._lock:
                            self._failure = "scanplanner_no_progress:{}".format(note)
                        break
                time.sleep(1.0 / self._rate_hz)

            if reached_pose is None:
                with self._lock:
                    if self._failure is None:
                        self._failure = "scanplanner_waypoint_timeout:{}".format(note)
                    reason = self._failure
                records.append({
                    "index": index,
                    "note": note,
                    "target": [target[0], target[1], float(waypoint["z"])],
                    "success": False,
                    "distance_error_m": (
                        round(distance, 4) if math.isfinite(distance) else None),
                    "replans": replans,
                })
                self._write_tour(floor, records, "failed", reason)
                return False

            scan_completed = False
            scan_rotation = 0.0
            if is_room_scan_waypoint(waypoint, floor["expected_rooms"]):
                scan_completed, scan_rotation = self._scan_room(
                    floor_number, waypoint)
                if not scan_completed:
                    records.append({
                        "index": index,
                        "note": note,
                        "target": [target[0], target[1], float(waypoint["z"])],
                        "success": False,
                        "scan_completed": False,
                        "scan_rotation_rad": round(scan_rotation, 3),
                        "reached_pose": [round(value, 4) for value in reached_pose],
                    })
                    with self._lock:
                        reason = self._failure
                    self._write_tour(floor, records, "failed", reason)
                    return False

            record = {
                "index": index,
                "note": note,
                "target": [target[0], target[1], float(waypoint["z"])],
                "success": True,
                "scan_completed": scan_completed,
                "scan_rotation_rad": round(scan_rotation, 3),
                "reached_pose": [round(value, 4) for value in reached_pose],
                "distance_error_m": round(distance, 4),
                "replans": replans,
                "effective_speed_limit_mps": round(effective_speed, 3),
                "elapsed_sec": round(time.monotonic() - started, 3),
                "wall_time": round(time.time(), 3),
            }
            records.append(record)
            self._sleep(max(0.0, float(
                waypoint.get("post_reach_settle_sec", 0.0))))
            self._record_event(
                "waypoint_reached", floor=floor_number, waypoint=note,
                distance_m=record["distance_error_m"],
                scan_completed=scan_completed)
            self._write_tour(floor, records, "running")

        self._write_tour(floor, records, "completed")
        self._record_event("floor_complete", floor=floor_number)
        return True

    def _trigger_floor_transition(self, floor_number):
        self._set_floor_enabled(False)
        if int(floor_number) == 1:
            publisher = self._baseline_state_pub
            token = "STAIR_WAIT_ZONE"
        elif int(floor_number) == 2:
            publisher = self._second_state_pub
            token = "SECOND_FLOOR_EXPLORATION_COMPLETE"
        else:
            publisher = self._third_state_pub
            token = "THIRD_FLOOR_EXPLORATION_COMPLETE"
        # The stair manager performs the plane->stair handoff at the aligned
        # landing through its mechanically safe FixedStand boundary.  A hot
        # reload here can apply an unrelated stair-policy action while the
        # plane gait still owns the joints and has physically rolled the dog
        # over in descent smoke testing.
        self._publish_route_state(
            "RELEASE_TO_STAIR_RL", floor=floor_number, token=token)
        for _ in range(3):
            publisher.publish(String(data=token))
            self._sleep(0.15)
        self._record_event("stair_trigger", floor=floor_number, token=token)
        return True

    def _state_is(self, topic, token):
        with self._lock:
            return self._manager_states.get(topic) == token

    def _restore_plane_and_release_manager(self, floor_number, manager_topic,
                                           reached_token, ready_publisher,
                                           ready_token, handoff_token):
        self._publish_route_state(
            "WAIT_UPPER_LANDING", floor=floor_number,
            expected=reached_token)
        if not self._wait(
                lambda: self._state_is(manager_topic, reached_token),
                self._handoff_timeout,
                "timeout_waiting_for_{}".format(reached_token.lower())):
            return False

        if not self._switch_rl_policy(
                self._plane_policy, "plane", "RESTORE_PLANE_RL",
                floor_number,
                "plane_policy_restore_timeout_floor_{}".format(floor_number)):
            return False

        ready_publisher.publish(String(data=ready_token))
        self._record_event(
            "upper_floor_plane_ready", floor=floor_number,
            token=ready_token)
        if not self._wait(
                lambda: self._state_is(manager_topic, handoff_token),
                self._handoff_timeout,
                "timeout_waiting_for_{}".format(handoff_token.lower())):
            return False
        self._sleep(self._manager_release_settle)
        return True

    def _publish_failure(self, floor_number):
        if int(floor_number) == 1:
            self._baseline_state_pub.publish(
                String(data="FIRST_FLOOR_EXPLORATION_FAILED"))
        elif int(floor_number) == 2:
            self._second_state_pub.publish(
                String(data="SECOND_FLOOR_EXPLORATION_FAILED"))
        else:
            self._third_state_pub.publish(
                String(data="THIRD_FLOOR_EXPLORATION_FAILED"))

    def _fail(self, floor_number):
        self._set_floor_enabled(False)
        self._publish_failure(floor_number)
        self._failed_pub.publish(Bool(data=True))
        with self._lock:
            reason = self._failure or "unknown_failure"
        self._publish_route_state(
            "THREE_FLOOR_ROUTE_FAILED", floor=floor_number, reason=reason)
        atomic_write_json(os.path.join(
            self._output_dir, "scanplanner_route_summary.json"), {
                "schema": "scanplanner_three_floor_route_v1",
                "status": "failed",
                "failure_reason": reason,
                "failed_floor": int(floor_number),
                "events": list(self._events),
            })
        rospy.logerr("SCAN three-floor route failed on F%d: %s",
                     floor_number, reason)

    def run(self):
        if not self._wait_for_startup():
            self._fail(1)
            return False

        # The entrance step is the mission's first physical motion, so make
        # its stair policy part of algorithm preparation.  The strict 600 s
        # clock starts only after this policy has emitted a fresh readiness
        # edge; the subsequent flat-policy restore remains task time.
        if not self._switch_rl_policy(
                self._stair_policy, "stair",
                "PREPARE_ENTRANCE_STAIR_RL", 1,
                "stair_policy_preparation_timeout_at_main_entrance"):
            self._fail(1)
            return False

        with self._lock:
            self._exploration_started_monotonic = time.monotonic()
            initial_pose = list(self._pose) if self._pose is not None else None
        self._publish_route_state(
            "EXPLORATION_STARTED",
            preparation_excluded=True,
            budget_sec=self._mission_budget,
            initial_odom_pose=initial_pose,
        )
        self._exploration_active_pub.publish(Bool(data=True))

        if not self._wait(
                self._clock_acknowledged,
                min(10.0, self._policy_timeout),
                "supervisor_exploration_clock_ack_timeout"):
            self._fail(1)
            return False

        self._publish_route_state(
            "ENTER_MAIN_ENTRANCE_STAIR_RL", floor=1,
            policy=self._stair_policy)
        self._sleep(self._stage_announcement_hold)

        for floor in self._config["floors"]:
            floor_number = int(floor["floor_number"])
            if floor_number == 2:
                if not self._restore_plane_and_release_manager(
                        2, "/simenv/stair_transition_state",
                        "SECOND_FLOOR_REACHED", self._second_state_pub,
                        "SECOND_FLOOR_EXPLORATION_READY",
                        "SECOND_FLOOR_HANDOFF_COMPLETE"):
                    self._fail(2)
                    return False
            elif floor_number == 3:
                if not self._restore_plane_and_release_manager(
                        3, "/simenv/second_to_third_floor_stair_state",
                        "THIRD_FLOOR_REACHED", self._third_state_pub,
                        "THIRD_FLOOR_EXPLORATION_READY",
                        "THIRD_FLOOR_HANDOFF_COMPLETE"):
                    self._fail(3)
                    return False

            if not self._run_floor(floor):
                self._fail(floor_number)
                return False
            if not self._trigger_floor_transition(floor_number):
                self._fail(floor_number)
                return False

        self._complete_pub.publish(Bool(data=True))
        self._publish_route_state(
            "THREE_FLOOR_SCAN_ROUTE_COMPLETE_DESCENT_ACTIVE")
        atomic_write_json(os.path.join(
            self._output_dir, "scanplanner_route_summary.json"), {
                "schema": "scanplanner_three_floor_route_v1",
                "status": "completed",
                "planner": "SCAN-Planner",
                "motion_backend": "plane_rl",
                "floors_completed": [1, 2, 3],
                "events": list(self._events),
            })
        rospy.loginfo(
            "SCAN explored all three floors; stair descent owns the return.")
        return True

    def _on_shutdown(self):
        self._publish_scan(False)
        self._publish_room_scan_active(False)
        self._floor_enable_pub.publish(Bool(data=False))


def main():
    rospy.init_node("scanplanner_three_floor_goal_sequencer", anonymous=False)
    sequencer = ThreeFloorGoalSequencer()
    sequencer.run()
    rospy.spin()


if __name__ == "__main__":
    main()
