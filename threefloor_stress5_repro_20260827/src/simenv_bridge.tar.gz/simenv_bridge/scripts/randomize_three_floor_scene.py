#!/usr/bin/env python3
"""Randomize a prepared three-floor scene and derive two scan poses per room.

All outputs are run-local.  Independent per-floor seeds control furniture and
red-ball placement, while the source generated scene remains unchanged.
"""

import argparse
import copy
import hashlib
import json
import math
import os
import random
import tempfile
import xml.etree.ElementTree as ET


def read_json(path):
    with open(path, "r", encoding="utf-8") as stream:
        return json.load(stream)


def atomic_json(path, payload):
    directory = os.path.dirname(os.path.abspath(path))
    os.makedirs(directory, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(
        prefix=".three-floor-randomization-", suffix=".json", dir=directory)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, ensure_ascii=False, indent=2, sort_keys=True)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise


def atomic_xml(tree, path):
    directory = os.path.dirname(os.path.abspath(path))
    descriptor, temporary = tempfile.mkstemp(
        prefix=".three-floor-randomization-", suffix=".xml", dir=directory)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            tree.write(stream, encoding="utf-8", xml_declaration=True)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def floor_index(floor):
    return int(floor.get("floor_index", -1))


def room_is_left(room):
    return float(room["bounds"]["x_max"]) < 0.0


def room_center_y(room):
    bounds = room["bounds"]
    return 0.5 * (float(bounds["y_min"]) + float(bounds["y_max"]))


def door_scan_xy(room):
    bounds = room["bounds"]
    # A direct waypoint may be accepted up to 0.25 m early.  One metre of
    # inset still leaves the robot centre >=0.75 m from the partition while
    # it rotates, avoiding the doorway-frame stall seen at a 0.65 m inset.
    x = (float(bounds["x_max"]) - 1.00 if room_is_left(room)
         else float(bounds["x_min"]) + 1.00)
    return x, room_center_y(room)


def oriented_extents(size, yaw):
    half_x, half_y = 0.5 * float(size[0]), 0.5 * float(size[1])
    cosine, sine = abs(math.cos(yaw)), abs(math.sin(yaw))
    return (cosine * half_x + sine * half_y,
            sine * half_x + cosine * half_y)


def point_box_clearance(x, y, furniture):
    pose, size = furniture["pose"], furniture["size"]
    yaw = float(pose[5]) if len(pose) > 5 else 0.0
    dx, dy = float(x) - float(pose[0]), float(y) - float(pose[1])
    cosine, sine = math.cos(yaw), math.sin(yaw)
    local_x = cosine * dx + sine * dy
    local_y = -sine * dx + cosine * dy
    outside_x = max(abs(local_x) - 0.5 * float(size[0]), 0.0)
    outside_y = max(abs(local_y) - 0.5 * float(size[1]), 0.0)
    return math.hypot(outside_x, outside_y)


def furniture_clearance(x, y, room):
    furniture = room.get("furniture", [])
    if not furniture:
        return float("inf")
    return min(point_box_clearance(x, y, item) for item in furniture)


def wall_clearance(x, y, room):
    bounds = room["bounds"]
    return min(float(x) - float(bounds["x_min"]),
               float(bounds["x_max"]) - float(x),
               float(y) - float(bounds["y_min"]),
               float(bounds["y_max"]) - float(y))


def segment_clear(x0, y0, x1, y1, room, clearance):
    for step in range(1, 40):
        ratio = step / 40.0
        x = x0 + ratio * (x1 - x0)
        y = y0 + ratio * (y1 - y0)
        if furniture_clearance(x, y, room) < clearance:
            return False
    return True


def segment_box_intersects(x0, y0, x1, y1, furniture, clearance=0.0):
    """Conservatively test a segment against an inflated yawed rectangle."""
    pose, size = furniture["pose"], furniture["size"]
    yaw = float(pose[5]) if len(pose) > 5 else 0.0
    cosine, sine = math.cos(yaw), math.sin(yaw)

    def local(x, y):
        dx, dy = float(x) - float(pose[0]), float(y) - float(pose[1])
        return (cosine * dx + sine * dy,
                -sine * dx + cosine * dy)

    start_x, start_y = local(x0, y0)
    end_x, end_y = local(x1, y1)
    delta_x, delta_y = end_x - start_x, end_y - start_y
    half_x = 0.5 * float(size[0]) + float(clearance)
    half_y = 0.5 * float(size[1]) + float(clearance)
    lower, upper = 0.0, 1.0
    for origin, delta, half_extent in (
            (start_x, delta_x, half_x), (start_y, delta_y, half_y)):
        if abs(delta) < 1.0e-12:
            if abs(origin) > half_extent:
                return False
            continue
        first = (-half_extent - origin) / delta
        second = (half_extent - origin) / delta
        if first > second:
            first, second = second, first
        lower = max(lower, first)
        upper = min(upper, second)
        if lower > upper:
            return False
    return True


def line_of_sight_clear(x0, y0, x1, y1, room, clearance=0.12):
    return not any(segment_box_intersects(
        x0, y0, x1, y1, item, clearance)
        for item in room.get("furniture", []))


def normalize_angle(angle):
    return math.atan2(math.sin(float(angle)), math.cos(float(angle)))


def safe_asin(ratio):
    """Clamp an asin input defensively into its mathematical domain."""
    return math.asin(max(-1.0, min(1.0, float(ratio))))


def scan_bearing_separation_rad(origin_x, origin_y, first_x, first_y,
                                 second_x, second_y):
    """Absolute centre-bearing difference between two points from one origin."""
    first = math.atan2(float(first_y) - float(origin_y),
                       float(first_x) - float(origin_x))
    second = math.atan2(float(second_y) - float(origin_y),
                        float(second_x) - float(origin_x))
    return abs(normalize_angle(second - first))


def required_projected_bearing_separation(radius_m, first_range_m,
                                          second_range_m, minimum_gap_rad):
    """Bearing separation that keeps two sphere silhouettes disjoint.

    A sphere of ``radius_m`` at range ``r`` subtends a half-angle
    ``asin(radius_m / r)`` from the scan origin, so the projected
    silhouettes keep ``minimum_gap_rad`` of empty bearing space only when
    the centre-bearing separation reaches the sum of both half-angles plus
    the configured gap.
    """
    return (safe_asin(float(radius_m) / max(float(first_range_m), 1.0e-9)) +
            safe_asin(float(radius_m) / max(float(second_range_m), 1.0e-9)) +
            float(minimum_gap_rad))


def projected_silhouettes_separated(scan, radius_m, first_x, first_y,
                                    second_x, second_y, minimum_gap_rad):
    """Return True when two balls cannot overlap in one scan's bearing space."""
    origin_x, origin_y = float(scan["pose"][0]), float(scan["pose"][1])
    first_range = math.hypot(float(first_x) - origin_x,
                             float(first_y) - origin_y)
    second_range = math.hypot(float(second_x) - origin_x,
                              float(second_y) - origin_y)
    separation = scan_bearing_separation_rad(
        origin_x, origin_y, first_x, first_y, second_x, second_y)
    return separation >= required_projected_bearing_separation(
        radius_m, first_range, second_range, minimum_gap_rad)


def directional_turn(start_yaw, end_yaw, turn_sign):
    return ((float(end_yaw) - float(start_yaw)) * float(turn_sign)) % (
        2.0 * math.pi)


def scan_observation_pause_count(turn_rad, interval_rad, end_margin_rad=0.30):
    """Count the stationary observations the sequencer will take in a turn."""
    turn = max(0.0, float(turn_rad))
    interval = float(interval_rad)
    if interval <= 0.0:
        return 0
    # _scan_room pauses at k*interval while that threshold is no closer than
    # end_margin_rad to the requested endpoint.  The epsilon preserves an
    # exactly-on-the-boundary pause despite ordinary float representation.
    return max(0, int(math.floor(
        (turn - float(end_margin_rad)) / interval + 1.0e-9)))


def scan_observes_point(x, y, scan, room, settings, include_camera_fov):
    sx, sy, _, yaw = [float(value) for value in scan["pose"]]
    distance = math.hypot(float(x) - sx, float(y) - sy)
    if include_camera_fov:
        minimum_range = float(settings.get(
            "scan_coverage_minimum_range_m", 0.75))
        maximum_range = float(settings.get(
            "scan_coverage_maximum_range_m", 6.50))
    else:
        minimum_range = float(scan.get("detection_minimum_range_m", 1.00))
        maximum_range = float(scan.get("detection_maximum_range_m", 6.00))
    if distance < minimum_range or distance > maximum_range:
        return False

    bearing = math.atan2(float(y) - sy, float(x) - sx)
    turn_sign = 1.0 if float(scan["scan_yaw_rate"]) >= 0.0 else -1.0
    progress = directional_turn(yaw, bearing, turn_sign)
    turn = float(scan["scan_turn_rad"])
    if include_camera_fov:
        half_fov = 0.5 * float(settings.get(
            "camera_horizontal_fov_rad", 1.0466666666666666))
        yaw_uncertainty = float(settings.get(
            "scan_start_yaw_uncertainty_rad", 0.18))
        edge = max(0.0, half_fov - yaw_uncertainty)
        inside_sector = progress <= turn + edge or progress >= 2.0 * math.pi - edge
    else:
        endpoint_margin = float(scan.get(
            "detection_heading_margin_rad", 0.35))
        inside_sector = endpoint_margin <= progress <= turn - endpoint_margin
    return inside_sector and line_of_sight_clear(sx, sy, x, y, room)


def room_observation_grid(room, settings):
    bounds = room["bounds"]
    resolution = float(settings.get("scan_coverage_grid_resolution_m", 0.40))
    wall_margin = float(settings.get("red_ball_wall_margin_m", 0.55))
    obstacle_margin = float(settings.get(
        "red_ball_furniture_clearance_m", 0.30))
    points = []
    y = float(bounds["y_min"]) + wall_margin
    while y <= float(bounds["y_max"]) - wall_margin + 1.0e-9:
        x = float(bounds["x_min"]) + wall_margin
        while x <= float(bounds["x_max"]) - wall_margin + 1.0e-9:
            if furniture_clearance(x, y, room) >= obstacle_margin:
                points.append((x, y))
            x += resolution
        y += resolution
    return points


def scan_pair_coverage(room, scans, settings, grid=None):
    grid = room_observation_grid(room, settings) if grid is None else grid
    covered = 0
    robust = 0
    for x, y in grid:
        if any(scan_observes_point(
                x, y, scan, room, settings, True) for scan in scans):
            covered += 1
        if any(scan_observes_point(
                x, y, scan, room, settings, False) for scan in scans):
            robust += 1
    total = len(grid)
    return {
        "grid_resolution_m": float(settings.get(
            "scan_coverage_grid_resolution_m", 0.40)),
        "observable_cell_count": total,
        "covered_cell_count": covered,
        "robust_detection_cell_count": robust,
        "coverage_fraction": (float(covered) / total if total else 0.0),
        "robust_detection_fraction": (float(robust) / total if total else 0.0),
        "camera_horizontal_fov_rad": float(settings.get(
            "camera_horizontal_fov_rad", 1.0466666666666666)),
        "coverage_minimum_range_m": float(settings.get(
            "scan_coverage_minimum_range_m", 0.75)),
        "coverage_maximum_range_m": float(settings.get(
            "scan_coverage_maximum_range_m", 6.50)),
    }


def build_floor_seeds(mission, floors, offset):
    settings = mission.setdefault("scene_randomization", {})
    base = settings.get("floor_seeds", [1103, 2207, 3301])
    if not isinstance(base, list) or len(base) != len(floors):
        raise ValueError("scene_randomization.floor_seeds must have one value per floor")
    effective = [int(value) + int(offset) for value in base]
    if len(set(effective)) != len(effective):
        raise ValueError("effective floor seeds must be pairwise distinct")
    expected_indices = list(range(len(floors)))
    actual_indices = [floor_index(floor) for floor in sorted(floors, key=floor_index)]
    if actual_indices != expected_indices:
        raise ValueError("layout floor_index values must be {}".format(expected_indices))
    return {index: effective[index] for index in expected_indices}


def randomize_furniture(layout, seed_by_floor, settings):
    poses = {}
    room_jitter_x = float(settings.get("furniture_room_jitter_x_m", 0.45))
    room_jitter_y = float(settings.get("furniture_room_jitter_y_m", 0.65))
    item_jitter = float(settings.get("furniture_item_jitter_m", 0.12))
    yaw_jitter = float(settings.get("furniture_yaw_jitter_rad", 0.18))
    wall_margin = float(settings.get("furniture_wall_margin_m", 0.20))

    for floor in sorted(layout["floors"], key=floor_index):
        index = floor_index(floor)
        floor["scene_seed"] = seed_by_floor[index]
        rng = random.Random(seed_by_floor[index] ^ 0x4F425354)
        for room in floor.get("rooms", []):
            shared_dx = rng.uniform(-room_jitter_x, room_jitter_x)
            shared_dy = rng.uniform(-room_jitter_y, room_jitter_y)
            for item in room.get("furniture", []):
                original = [float(value) for value in item["pose"]]
                size = [float(value) for value in item["size"]]
                selected = None
                for attempt in range(180):
                    if attempt < 120:
                        scale = 1.0
                    elif attempt < 160:
                        scale = 0.30
                    else:
                        scale = 0.05
                    yaw = original[5] + rng.uniform(-yaw_jitter, yaw_jitter) * scale
                    x = original[0] + shared_dx * scale + rng.uniform(-item_jitter, item_jitter) * scale
                    y = original[1] + shared_dy * scale + rng.uniform(-item_jitter, item_jitter) * scale
                    extent_x, extent_y = oriented_extents(size, yaw)
                    bounds = room["bounds"]
                    if x - extent_x < float(bounds["x_min"]) + wall_margin:
                        continue
                    if x + extent_x > float(bounds["x_max"]) - wall_margin:
                        continue
                    if y - extent_y < float(bounds["y_min"]) + wall_margin:
                        continue
                    if y + extent_y > float(bounds["y_max"]) - wall_margin:
                        continue
                    scan_x, scan_y = door_scan_xy(room)
                    scan_minimum = float(settings.get(
                        "scan_point_minimum_furniture_clearance_m", 0.65))
                    scan_reserve = max(scan_minimum, float(settings.get(
                        "door_scan_furniture_reserve_m", 0.78)))
                    candidate_item = {"pose": [x, y, original[2],
                                                original[3], original[4], yaw],
                                      "size": size}
                    if point_box_clearance(
                            scan_x, scan_y, candidate_item) < scan_reserve:
                        continue
                    selected = [x, y, original[2], original[3], original[4], yaw]
                    break
                if selected is None:
                    raise ValueError("could not safely randomize {}".format(item["id"]))
                item["pose"] = selected
                item_id = str(item["id"])
                if item_id in poses:
                    raise ValueError("duplicate furniture id {}".format(item_id))
                poses[item_id] = selected
    return poses


def derive_scan_points(layout, seed_by_floor, settings):
    points = {}
    minimum = float(settings.get("scan_point_minimum_furniture_clearance_m", 0.65))
    path_minimum = float(settings.get(
        "scan_path_minimum_furniture_clearance_m", 0.50))
    separation = float(settings.get("scan_point_minimum_separation_m", 0.80))
    maximum_separation = float(settings.get(
        "scan_point_maximum_separation_m", 1.50))
    maximum_local_route = float(settings.get(
        "scan_pair_maximum_local_route_m", 5.40))
    yaw_rate = abs(float(settings.get("scan_yaw_rate_rad_s", 1.00)))
    scan_minimum_turn = float(settings.get(
        "scan_point_minimum_turn_rad", 0.40))
    scan_maximum_turn = float(settings.get(
        "scan_point_maximum_turn_rad", 2.65))
    combined_minimum_turn = float(settings.get(
        "scan_pair_minimum_combined_turn_rad", 2.80))
    combined_maximum_turn = float(settings.get(
        "scan_pair_maximum_combined_turn_rad", 3.65))
    alternate_directions = bool(settings.get(
        "alternate_scan_turn_directions", True))
    scan_a_settle = float(settings.get("scan_a_settle_sec", 0.25))
    scan_b_settle = float(settings.get("scan_b_settle_sec", 0.20))
    last_room_settle = float(settings.get(
        "last_room_scan_settle_sec", 0.30))
    scan_pause_interval = float(settings.get(
        "scan_pause_interval_rad", 0.0))
    scan_pause_dwell = float(settings.get(
        "scan_pause_dwell_sec", 0.60))
    scan_a_navigation_speed = float(settings.get(
        "scan_a_navigation_speed", 0.50))
    scan_b_navigation_speed = float(settings.get(
        "scan_b_navigation_speed", 0.35))
    detection_minimum_range = float(settings.get(
        "red_ball_scan_minimum_range_m", 1.00))
    detection_maximum_range = float(settings.get(
        "red_ball_scan_maximum_range_m", 6.00))
    detection_heading_margin = float(settings.get(
        "red_ball_scan_heading_margin_rad", 0.35))
    candidate_depths = [float(value) for value in settings.get(
        "scan_candidate_depths_m", [0.70, 0.85, 1.00, 1.15, 1.30, 1.45])]
    maximum_y_offset = float(settings.get(
        "scan_candidate_maximum_y_offset_m", 0.60))
    y_offset_step = float(settings.get(
        "scan_candidate_y_offset_step_m", 0.20))
    floor_speed = float(settings.get("coverage_time_floor_speed_mps", 1.65))
    minimum_robust_fraction = float(settings.get(
        "minimum_robust_detection_fraction", 0.05))

    for floor in sorted(layout["floors"], key=floor_index):
        index = floor_index(floor)
        elevation = float(floor["elevation"])
        floor_rooms = list(floor.get("rooms", []))
        floor_candidates = []
        for room_index, room in enumerate(floor_rooms):
            room_id = str(room["id"])
            left = room_is_left(room)
            direction = -1.0 if left else 1.0
            bounds = room["bounds"]
            near_wall_x = (float(bounds["x_max"]) if left
                           else float(bounds["x_min"]))
            centre_y = room_center_y(room)
            entry = (0.0, centre_y)
            offsets = []
            offset = -maximum_y_offset
            while offset <= maximum_y_offset + 1.0e-9:
                offsets.append(round(offset, 9))
                offset += y_offset_step
            poses = []
            for depth in candidate_depths:
                x = near_wall_x + direction * depth
                for y_offset in offsets:
                    y = centre_y + y_offset
                    if wall_clearance(x, y, room) < minimum:
                        continue
                    if furniture_clearance(x, y, room) < minimum:
                        continue
                    if not segment_clear(
                            entry[0], entry[1], x, y, room, path_minimum):
                        continue
                    crossing_factor = abs(near_wall_x / x)
                    if abs(y_offset) * crossing_factor > 0.70:
                        continue
                    poses.append((x, y))

            grid = room_observation_grid(room, settings)
            candidates_by_sign = {-1.0: [], 1.0: []}
            evaluated_pairs = {-1.0: 0, 1.0: 0}
            for scan_a in poses:
                start_yaw = math.atan2(
                    scan_a[1] - entry[1], scan_a[0] - entry[0])
                for scan_b in poses:
                    point_separation = math.hypot(
                        scan_b[0] - scan_a[0], scan_b[1] - scan_a[1])
                    if not separation <= point_separation <= maximum_separation:
                        continue
                    if not segment_clear(
                            scan_a[0], scan_a[1], scan_b[0], scan_b[1],
                            room, path_minimum):
                        continue
                    local_route = (
                        math.hypot(scan_a[0] - entry[0],
                                   scan_a[1] - entry[1]) +
                        point_separation +
                        math.hypot(entry[0] - scan_b[0],
                                   entry[1] - scan_b[1]))
                    if local_route > maximum_local_route:
                        continue
                    transition_yaw = math.atan2(
                        scan_b[1] - scan_a[1],
                        scan_b[0] - scan_a[0])
                    exit_yaw = math.atan2(
                        entry[1] - scan_b[1], entry[0] - scan_b[0])
                    for turn_sign in (-1.0, 1.0):
                        first_turn = directional_turn(
                            start_yaw, transition_yaw, turn_sign)
                        second_turn = directional_turn(
                            transition_yaw, exit_yaw, turn_sign)
                        combined_turn = first_turn + second_turn
                        if not (scan_minimum_turn <= first_turn <= scan_maximum_turn and
                                scan_minimum_turn <= second_turn <= scan_maximum_turn and
                                combined_minimum_turn <= combined_turn <=
                                combined_maximum_turn):
                            continue
                        definitions = [
                            {"id": room_id + "_scan_a", "room_id": room_id,
                             "pose": [scan_a[0], scan_a[1], elevation,
                                      start_yaw],
                             "scan_turn_rad": first_turn,
                             "scan_yaw_rate": turn_sign * yaw_rate,
                             "scan_settle_sec": scan_a_settle,
                             "scan_pause_interval_rad": scan_pause_interval,
                             "scan_pause_dwell_sec": scan_pause_dwell,
                             "navigation_speed": scan_a_navigation_speed,
                             "detection_minimum_range_m": detection_minimum_range,
                             "detection_maximum_range_m": detection_maximum_range,
                             "detection_heading_margin_rad": detection_heading_margin},
                            {"id": room_id + "_scan_b", "room_id": room_id,
                             "pose": [scan_b[0], scan_b[1], elevation,
                                      transition_yaw],
                             "scan_turn_rad": second_turn,
                             "scan_yaw_rate": turn_sign * yaw_rate,
                             "scan_settle_sec": scan_b_settle,
                             "scan_pause_interval_rad": scan_pause_interval,
                             "scan_pause_dwell_sec": scan_pause_dwell,
                             "navigation_speed": scan_b_navigation_speed,
                             "detection_minimum_range_m": detection_minimum_range,
                             "detection_maximum_range_m": detection_maximum_range,
                             "detection_heading_margin_rad": detection_heading_margin},
                        ]
                        coverage = scan_pair_coverage(
                            room, definitions, settings, grid)
                        evaluated_pairs[turn_sign] += 1
                        if coverage["robust_detection_cell_count"] <= 0:
                            continue
                        clearance = min(
                            wall_clearance(scan_a[0], scan_a[1], room),
                            wall_clearance(scan_b[0], scan_b[1], room),
                            furniture_clearance(scan_a[0], scan_a[1], room),
                            furniture_clearance(scan_b[0], scan_b[1], room))
                        speed_scale = float(settings.get(
                            "coverage_time_speed_scale", 2.60))
                        first_distance = math.hypot(
                            scan_a[0] - entry[0], scan_a[1] - entry[1])
                        exit_distance = math.hypot(
                            entry[0] - scan_b[0], entry[1] - scan_b[1])
                        observation_pause_count = (
                            scan_observation_pause_count(
                                first_turn, scan_pause_interval) +
                            scan_observation_pause_count(
                                second_turn, scan_pause_interval))
                        observation_pause_time = (
                            observation_pause_count * scan_pause_dwell)
                        estimated_seconds = (
                            first_distance / max(
                                0.1, min(floor_speed, speed_scale *
                                         scan_a_navigation_speed)) +
                            point_separation / max(
                                0.1, min(floor_speed, speed_scale *
                                         scan_b_navigation_speed)) +
                            exit_distance / max(0.1, floor_speed) +
                            combined_turn / max(0.1, yaw_rate) +
                            scan_a_settle + scan_b_settle +
                            observation_pause_time)
                        candidate = {
                            "definitions": definitions,
                            "coverage": coverage,
                            "local_route_distance_m": local_route,
                            "combined_turn_rad": combined_turn,
                            "estimated_seconds": estimated_seconds,
                            "observation_pause_count": observation_pause_count,
                            "observation_pause_time_sec": observation_pause_time,
                            "minimum_clearance_m": clearance,
                            "turn_sign": turn_sign,
                        }
                        candidates_by_sign[turn_sign].append(candidate)

            best_by_sign = {}
            for turn_sign, candidates in candidates_by_sign.items():
                robust_candidates = [
                    item for item in candidates
                    if item["coverage"]["robust_detection_fraction"] >=
                    minimum_robust_fraction]
                if not robust_candidates:
                    continue
                # Coverage is lexicographically primary inside the explicit
                # route/turn budget.  Time and clearance only break equal-cell
                # ties, so the selected pair is the maximum-coverage feasible
                # pair rather than merely the shortest pair near the door.
                best_by_sign[turn_sign] = max(
                    robust_candidates,
                    key=lambda item: (
                        item["coverage"]["covered_cell_count"],
                        item["coverage"]["robust_detection_cell_count"],
                        -item["estimated_seconds"],
                        item["minimum_clearance_m"]))
                best_by_sign[turn_sign]["candidate_pair_count"] = (
                    evaluated_pairs[turn_sign])
            if not best_by_sign:
                raise ValueError(
                    "could not derive a coverage-safe scan pair for {}"
                    .format(room_id))
            floor_candidates.append({
                "room_index": room_index,
                "room": room,
                "room_id": room_id,
                "best_by_sign": best_by_sign,
            })

        # Four consecutive same-direction half turns proved capable of
        # accumulating enough lateral attitude error to overturn the plane
        # policy on the final room.  Solve all four room directions together:
        # require two turns each way and prefer strict alternation, but retain
        # a safe balanced solution when furniture blocks one side of a room.
        selected_signs = [None] * len(floor_candidates)
        if alternate_directions:
            preferred = [
                -1.0 if (index + room_index) % 2 == 0 else 1.0
                for room_index in range(len(floor_candidates))]
            patterns = []
            for mask in range(1 << len(floor_candidates)):
                signs = [
                    1.0 if mask & (1 << room_index) else -1.0
                    for room_index in range(len(floor_candidates))]
                if sum(signs) != 0.0:
                    continue
                if not all(sign in context["best_by_sign"]
                           for context, sign in zip(floor_candidates, signs)):
                    continue
                repeated = sum(
                    first == second for first, second in zip(signs, signs[1:]))
                preference_changes = sum(
                    actual != wanted for actual, wanted in zip(signs, preferred))
                selected = [
                    context["best_by_sign"][sign]
                    for context, sign in zip(floor_candidates, signs)]
                minimum_coverage = min(
                    item["coverage"]["coverage_fraction"] for item in selected)
                total_coverage = sum(
                    item["coverage"]["coverage_fraction"] for item in selected)
                total_time = sum(item["estimated_seconds"] for item in selected)
                patterns.append((repeated, -minimum_coverage, -total_coverage,
                                 total_time, preference_changes, signs))
            if not patterns:
                raise ValueError(
                    "could not balance scan turn directions on floor {}"
                    .format(index))
            selected_signs = min(patterns, key=lambda item: item[:5])[5]

        for context, selected_sign in zip(floor_candidates, selected_signs):
            room_index = context["room_index"]
            room = context["room"]
            room_id = context["room_id"]
            if selected_sign is None:
                selected = max(
                    context["best_by_sign"].values(),
                    key=lambda item: item["coverage"]["covered_cell_count"])
            else:
                selected = context["best_by_sign"][selected_sign]
            second_settle = (last_room_settle
                             if room_index == len(floor_rooms) - 1
                             else scan_b_settle)
            definitions = copy.deepcopy(selected["definitions"])
            definitions[1]["scan_settle_sec"] = second_settle
            coverage = copy.deepcopy(selected["coverage"])
            coverage.update({
                "candidate_pair_count": selected["candidate_pair_count"],
                "local_route_distance_m": selected["local_route_distance_m"],
                "combined_turn_rad": selected["combined_turn_rad"],
                "estimated_pair_time_sec": (
                    selected["estimated_seconds"] - scan_b_settle +
                    second_settle),
                "observation_pause_count": selected[
                    "observation_pause_count"],
                "observation_pause_time_sec": selected[
                    "observation_pause_time_sec"],
                "minimum_scan_clearance_m": selected["minimum_clearance_m"],
                "optimization": "maximum_covered_cells_within_time_constraints",
            })
            room["scan_points"] = copy.deepcopy(definitions)
            room["scan_coverage"] = coverage
            points[room_id] = definitions
    return points


def visible_in_scan(x, y, scan):
    sx, sy, _, yaw = [float(value) for value in scan["pose"]]
    distance = math.hypot(float(x) - sx, float(y) - sy)
    # Keep targets close enough to remain comfortably above the RGB contour
    # area threshold and away from sweep endpoints long enough to produce at
    # least three processed frames.
    minimum_range = float(scan.get("detection_minimum_range_m", 1.00))
    maximum_range = float(scan.get("detection_maximum_range_m", 6.00))
    if distance < minimum_range or distance > maximum_range:
        return False
    bearing = math.atan2(float(y) - sy, float(x) - sx)
    if float(scan["scan_yaw_rate"]) >= 0.0:
        progress = (bearing - yaw) % (2.0 * math.pi)
    else:
        progress = (yaw - bearing) % (2.0 * math.pi)
    turn = float(scan["scan_turn_rad"])
    endpoint_margin = float(scan.get(
        "detection_heading_margin_rad", min(0.35, 0.25 * turn)))
    return endpoint_margin <= progress <= turn - endpoint_margin


def danger_name(floor, index):
    base = "danger_red_sphere_{:02d}".format(index)
    return base if floor == 0 else "{}_floor_{}".format(base, floor)


def place_red_balls(layout, scans, seed_by_floor, settings):
    per_floor = int(settings.get("red_balls_per_floor", 6))
    if per_floor < 4:
        raise ValueError("red_balls_per_floor must be at least four")
    radius = float(settings.get("red_ball_radius_m", 0.15))
    wall_margin = float(settings.get("red_ball_wall_margin_m", 0.55))
    obstacle_margin = float(settings.get("red_ball_furniture_clearance_m", 0.30))
    separation = float(settings.get("red_ball_minimum_separation_m", 1.35))
    los_clearance = float(settings.get(
        "red_ball_line_of_sight_clearance_m", 0.22))
    projected_gap = float(settings.get(
        "red_ball_minimum_projected_gap_rad", 0.05235987755982989))
    poses, truth = {}, []

    for floor in sorted(layout["floors"], key=floor_index):
        index = floor_index(floor)
        elevation = float(floor["elevation"])
        rng = random.Random(seed_by_floor[index] ^ 0x52454442)
        rooms = list(floor.get("rooms", []))
        if len(rooms) != 4:
            raise ValueError("floor {} must contain four rooms".format(index))
        extra_rooms = set(rng.sample(range(len(rooms)), per_floor - len(rooms)))
        counts = [1 + int(room_index in extra_rooms)
                  for room_index in range(len(rooms))]
        floor_positions = []
        ball_index = 0
        for room_index, room in enumerate(rooms):
            room_id = str(room["id"])
            bounds = room["bounds"]
            room_truth = []
            for _ in range(counts[room_index]):
                selected = None
                for _attempt in range(4000):
                    x = rng.uniform(float(bounds["x_min"]) + wall_margin,
                                    float(bounds["x_max"]) - wall_margin)
                    y = rng.uniform(float(bounds["y_min"]) + wall_margin,
                                    float(bounds["y_max"]) - wall_margin)
                    if furniture_clearance(x, y, room) < obstacle_margin:
                        continue
                    if any(math.hypot(x - old_x, y - old_y) < separation
                           for old_x, old_y in floor_positions):
                        continue
                    # Balls are sampled only from the central swept sector,
                    # not merely from the edge of the camera FOV.  This leaves
                    # enough observation time for three independent 10 Hz RGB
                    # confirmations even with approach-yaw uncertainty.
                    visible_scans = [
                        scan for scan in scans[room_id]
                        if visible_in_scan(x, y, scan) and
                        line_of_sight_clear(
                            float(scan["pose"][0]),
                            float(scan["pose"][1]), x, y, room,
                            los_clearance)]
                    if not visible_scans:
                        continue
                    # Two same-room balls that share a valid scan must keep
                    # disjoint projected silhouettes in that scan's bearing
                    # space, otherwise the RGB contour stage can fuse them
                    # into one confirmed source.  Pairs assigned to
                    # different, non-shared scans are allowed.
                    if any(
                        not projected_silhouettes_separated(
                            scan, radius, x, y,
                            float(prior["pose"][0]),
                            float(prior["pose"][1]), projected_gap)
                        for prior in room_truth
                        for scan in visible_scans
                        if str(scan["id"]) in {
                            str(value) for value in prior["visible_scan_ids"]}):
                        continue
                    selected = (x, y, visible_scans)
                    break
                if selected is None:
                    raise ValueError(
                        "could not place a red ball in {} under the conservative "
                        "line-of-sight and projected-separation placement "
                        "constraints".format(room_id))
                x, y, visible_scans = selected
                model_name = danger_name(index, ball_index)
                pose = [x, y, elevation + radius, 0.0, 0.0, 0.0]
                record = {"id": model_name, "floor_index": index,
                          "room_id": room_id, "pose": pose,
                          "radius_m": radius,
                          "visible_scan_ids": [
                              str(scan["id"]) for scan in visible_scans]}
                poses[model_name] = pose
                truth.append(record)
                room_truth.append(copy.deepcopy(record))
                floor_positions.append((x, y))
                ball_index += 1
            room["red_balls"] = room_truth
        if ball_index != per_floor:
            raise ValueError("floor {} red-ball count is {}, expected {}".format(
                index, ball_index, per_floor))
    layout["danger_red_spheres"] = copy.deepcopy(truth)
    return poses, truth


def rewrite_route(mission, scans):
    for floor in mission.get("floors", []):
        rewritten = []
        for waypoint in floor.get("waypoints", []):
            note = str(waypoint.get("note", ""))
            if not note.endswith("_center"):
                rewritten.append(waypoint)
                continue
            room_id = note[:-len("_center")]
            if room_id not in scans:
                raise ValueError("missing scan points for {}".format(room_id))
            try:
                room_index = int(room_id.rsplit("_", 1)[1])
            except (IndexError, ValueError):
                room_index = 0
            if room_index % 2 == 1:
                # Do not cut diagonally through both partition walls between
                # paired rooms.  Visiting the door centre adds almost no path
                # length, gives the A1 full footprint clearance, and prevents
                # the 44 s door-frame scrape observed in physical seed 0.
                corridor = copy.deepcopy(waypoint)
                corridor.update({"x": 0.0,
                                 "y": float(waypoint["y"]),
                                 "note": room_id + "_corridor_entry",
                                 "speed": 0.55,
                                 "align_yaw": False,
                                 "tolerance": 0.30})
                corridor.pop("scan", None)
                rewritten.append(corridor)
            for definition in scans[room_id]:
                scan = copy.deepcopy(waypoint)
                scan.update({"x": definition["pose"][0],
                             "y": definition["pose"][1],
                             "yaw": definition["pose"][3],
                             "speed": definition["navigation_speed"],
                             "note": definition["id"],
                             "scan": True,
                             "align_yaw": False,
                             "scan_turn_rad": definition["scan_turn_rad"],
                             "scan_yaw_rate": definition["scan_yaw_rate"],
                             "scan_settle_sec": definition["scan_settle_sec"],
                             "scan_pause_interval_rad": definition[
                                 "scan_pause_interval_rad"],
                             "scan_pause_dwell_sec": definition[
                                 "scan_pause_dwell_sec"],
                             "tolerance": min(float(scan.get("tolerance", 0.40)), 0.25)})
                rewritten.append(scan)
        floor["waypoints"] = rewritten


def pose_text(values):
    return " ".join("{:.9g}".format(float(value)) for value in values)


def update_asset(path, furniture_poses, danger_poses, require_dangers):
    tree = ET.parse(path)
    root = tree.getroot()
    seen_furniture, seen_dangers = set(), set()
    for link in root.iter("link"):
        name = str(link.get("name", ""))
        if name not in furniture_poses:
            continue
        pose = link.find("pose")
        if pose is None:
            raise ValueError("{}: furniture {} has no pose".format(path, name))
        pose.text = pose_text(furniture_poses[name])
        seen_furniture.add(name)
    for model in root.iter("model"):
        name = str(model.get("name", ""))
        if name not in danger_poses:
            continue
        pose = model.find("pose")
        if pose is None:
            raise ValueError("{}: red ball {} has no pose".format(path, name))
        pose.text = pose_text(danger_poses[name])
        seen_dangers.add(name)
    missing_furniture = sorted(set(furniture_poses) - seen_furniture)
    if missing_furniture:
        raise ValueError("{}: missing furniture links {}".format(path, missing_furniture))
    missing_dangers = sorted(set(danger_poses) - seen_dangers)
    if require_dangers and missing_dangers:
        raise ValueError("{}: missing red-ball models {}".format(path, missing_dangers))
    atomic_xml(tree, path)
    return {"sha256": sha256(path),
            "furniture_links_updated": len(seen_furniture),
            "red_ball_models_updated": len(seen_dangers)}


def build_randomized_scene(source_layout, source_mission, seed_offset=0):
    """Return randomized layout/config payloads plus XML pose updates."""
    layout = copy.deepcopy(source_layout)
    mission = copy.deepcopy(source_mission)
    floors = layout.get("floors", [])
    if len(floors) != 3:
        raise ValueError("three-floor scene requires exactly three floors")
    seed_by_floor = build_floor_seeds(mission, floors, seed_offset)
    settings = mission.setdefault("scene_randomization", {})
    settings["effective_floor_seeds"] = [
        seed_by_floor[index] for index in range(3)]
    settings["seed_offset"] = int(seed_offset)

    furniture_poses = randomize_furniture(layout, seed_by_floor, settings)
    scans = derive_scan_points(layout, seed_by_floor, settings)
    danger_poses, red_truth = place_red_balls(
        layout, scans, seed_by_floor, settings)
    rewrite_route(mission, scans)

    room_coverages = [
        room["scan_coverage"]
        for floor in layout.get("floors", [])
        for room in floor.get("rooms", [])]
    runtime_floor_route = sum(
        sum(math.hypot(float(right["x"]) - float(left["x"]),
                       float(right["y"]) - float(left["y"]))
            for left, right in zip(
                floor.get("waypoints", []), floor.get("waypoints", [])[1:]))
        for floor in mission.get("floors", []))
    minimum_coverage = min(
        item["coverage_fraction"] for item in room_coverages)
    required_coverage = float(settings.get(
        "minimum_room_scan_coverage_fraction", 0.33))
    if minimum_coverage < required_coverage:
        raise ValueError(
            "minimum optimized room coverage {:.3f} is below {:.3f}"
            .format(minimum_coverage, required_coverage))
    maximum_runtime_route = float(settings.get(
        "maximum_runtime_floor_route_m", 239.0))
    if runtime_floor_route > maximum_runtime_route:
        raise ValueError(
            "optimized floor route {:.2f} m exceeds {:.2f} m time budget"
            .format(runtime_floor_route, maximum_runtime_route))
    metadata = layout.setdefault("metadata", {})
    metadata.update({"scene_randomized": True,
                     "floor_seeds": [seed_by_floor[index] for index in range(3)],
                     "seed_offset": int(seed_offset),
                     "red_ball_count": len(red_truth),
                     "scan_points_per_room": 2,
                     "minimum_room_scan_coverage_fraction": minimum_coverage,
                     "minimum_robust_detection_fraction": min(
                         item["robust_detection_fraction"]
                         for item in room_coverages),
                     "mean_room_scan_coverage_fraction": sum(
                         item["coverage_fraction"] for item in room_coverages) /
                         len(room_coverages),
                     "estimated_room_scan_time_sec": sum(
                         item["estimated_pair_time_sec"]
                         for item in room_coverages),
                     "runtime_floor_route_m": runtime_floor_route,
                     "alternate_scan_turn_directions": bool(
                         settings.get("alternate_scan_turn_directions", True))})
    layout.setdefault("target_points", {})["room_scans"] = {
        definition["id"]: [definition["pose"][0], definition["pose"][1],
                           definition["pose"][2], 0.0, 0.0,
                           definition["pose"][3]]
        for definitions in scans.values() for definition in definitions
    }

    red_config = mission.setdefault("red_ball_detection", {})
    red_config.update({"minimum_confirmed_detections": len(red_truth),
                       "expected_scene_red_balls": len(red_truth),
                       "expected_red_balls_per_floor": int(
                           settings.get("red_balls_per_floor", 6)),
                       "require_all_scene_red_balls": True})
    red_config.setdefault("matching_tolerance_m", 1.0)
    return (layout, mission, furniture_poses, danger_poses, red_truth,
            scans, seed_by_floor)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--world", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--layout", required=True)
    parser.add_argument("--mission-config", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--seed-offset", type=int, default=0)
    args = parser.parse_args()

    (layout, mission, furniture_poses, danger_poses, red_truth,
     scans, seed_by_floor) = build_randomized_scene(
        read_json(args.layout), read_json(args.mission_config), args.seed_offset)
    output_layout = os.path.join(args.output_dir, "layout_metadata.json")
    output_mission = os.path.join(args.output_dir, "mission_config.json")
    mission["runtime"]["world_file"] = os.path.abspath(args.world)
    mission["runtime"]["layout_metadata"] = os.path.abspath(output_layout)
    mission["runtime"]["stair_model_sdf"] = os.path.abspath(args.model)

    assets = {"world": update_asset(args.world, furniture_poses, danger_poses, True),
              "model": update_asset(args.model, furniture_poses, danger_poses, False)}
    atomic_json(output_layout, layout)
    atomic_json(output_mission, mission)
    manifest = {
        "schema": "simenv_three_floor_scene_randomization_v1",
        "passed": True,
        "source_layout": os.path.abspath(args.layout),
        "source_mission_config": os.path.abspath(args.mission_config),
        "output_layout": os.path.abspath(output_layout),
        "output_mission_config": os.path.abspath(output_mission),
        "floor_seeds": [seed_by_floor[index] for index in range(3)],
        "seed_offset": int(args.seed_offset),
        "furniture_pose_count": len(furniture_poses),
        "red_ball_count": len(red_truth),
        "scan_point_count": sum(len(value) for value in scans.values()),
        "minimum_room_scan_coverage_fraction": layout["metadata"][
            "minimum_room_scan_coverage_fraction"],
        "mean_room_scan_coverage_fraction": layout["metadata"][
            "mean_room_scan_coverage_fraction"],
        "minimum_robust_detection_fraction": layout["metadata"][
            "minimum_robust_detection_fraction"],
        "runtime_floor_route_m": layout["metadata"]["runtime_floor_route_m"],
        "estimated_room_scan_time_sec": layout["metadata"][
            "estimated_room_scan_time_sec"],
        "assets": assets,
    }
    manifest_path = os.path.join(args.output_dir, "scene_randomization.json")
    atomic_json(manifest_path, manifest)
    print(json.dumps(manifest, sort_keys=True))


if __name__ == "__main__":
    main()
