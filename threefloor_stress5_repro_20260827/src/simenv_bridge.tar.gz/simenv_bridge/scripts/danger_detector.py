#!/usr/bin/env python3
"""Detect red spherical danger sources and publish world-frame positions."""
import json
import math
import os
import sys
import threading
import time
from collections import deque

import cv2
import numpy as np


DANGER_Z = 0.15


def should_update_detections(scan_active):
    """Accumulate points only during a stationary room scan."""
    return bool(scan_active)


def scan_min_points(label):
    """Return the evidence threshold for a completed room scan.

    The front-left room is the only staging point with a very short visible
    dwell in the four-room route.  Requiring several synchronized frames
    there drops both balls when Gazebo publishes sparse RGB/depth pairs.
    Other scans retain a multi-frame threshold to suppress transient
    projections and partially visible distractors.
    """
    return 1 if str(label) == "room_LF_scan" else 3


def cluster_scan_points(points, merge_radius=1.2, min_points=2):
    """Collapse one scan's noisy projections to robust median world points."""
    clusters = []
    for point in points:
        x, y = float(point[0]), float(point[1])
        frame_id = point[2] if len(point) > 2 else None
        nearest = None
        nearest_distance = float("inf")
        for cluster in clusters:
            if frame_id is not None and frame_id in cluster["frames"]:
                continue
            distance = math.hypot(x - cluster["x"], y - cluster["y"])
            if distance < nearest_distance:
                nearest, nearest_distance = cluster, distance
        if nearest is None or nearest_distance > float(merge_radius):
            clusters.append({"x": x, "y": y, "points": [(x, y)], "frames": {frame_id}})
        else:
            nearest["points"].append((x, y))
            nearest["frames"].add(frame_id)
            values = np.asarray(nearest["points"], dtype=float)
            nearest["x"], nearest["y"] = np.median(values, axis=0)
    return [
        (cluster["x"], cluster["y"])
        for cluster in clusters
        if len(cluster["points"]) >= int(min_points)
    ]


def nearest_pose(samples, stamp, fallback):
    """Return the odometry sample closest to a camera timestamp."""
    if not samples:
        return fallback
    sample = min(samples, key=lambda value: abs(float(value[0]) - float(stamp)))
    return sample[1], sample[2]


def select_sphere_depth(sensor_depth, radius_px, fx, sphere_radius=DANGER_Z):
    """Prefer size-derived range when a depth pixel lands behind the red sphere."""
    if radius_px <= 0.0:
        return sensor_depth
    apparent_depth = float(fx) * float(sphere_radius) / float(radius_px)
    if not 0.2 <= apparent_depth <= 8.0:
        return sensor_depth
    if sensor_depth is None:
        return apparent_depth
    tolerance = max(0.35, apparent_depth * 0.30)
    return float(sensor_depth) if abs(float(sensor_depth) - apparent_depth) <= tolerance else apparent_depth


class CameraCalibration:
    def __init__(self, width, height, fx, fy, cx, cy, xyz_base, pitch):
        self.width = int(width)
        self.height = int(height)
        self.fx = float(fx)
        self.fy = float(fy)
        self.cx = float(cx)
        self.cy = float(cy)
        self.xyz_base = np.asarray(xyz_base, dtype=float)
        self.pitch = float(pitch)

    @classmethod
    def front_camera_fallback(cls):
        focal = 400.0 / math.tan(math.radians(40.0))
        return cls(800, 800, focal, focal, 400.0, 400.0, (0.27, 0.0, 0.05), 0.4)

    @classmethod
    def real_sense_fallback(cls):
        return cls(640, 480, 554.5940455, 554.5940455, 320.5, 240.5, (0.28, 0.0, 0.043), 0.0)

    @classmethod
    def recording_camera_fallback(cls):
        focal = 320.0 / math.tan(math.radians(30.0))
        return cls(640, 480, focal, focal, 320.0, 240.0,
                   (0.30, 0.0, 0.08), 0.0)

    @classmethod
    def from_camera_info(cls, msg, fallback=None):
        fallback = fallback or cls.front_camera_fallback()
        if not msg.K or msg.K[0] <= 0.0 or msg.K[4] <= 0.0:
            return fallback
        return cls(msg.width, msg.height, msg.K[0], msg.K[4], msg.K[2], msg.K[5],
                   fallback.xyz_base, fallback.pitch)


class DetectionTracker:
    def __init__(self, merge_radius=0.9, confirm_count=3):
        self.merge_radius = float(merge_radius)
        self.confirm_count = int(confirm_count)
        self.tracks = []
        self._next_id = 1
        self.last_newly_confirmed = []

    def update(self, points, metadata=None):
        """Update 2-D or floor-aware 3-D tracks.

        A track may consume at most one candidate from a camera frame.  This
        prevents two nearby balls visible simultaneously from being collapsed
        into one source while still averaging projection noise over time.
        """
        used_tracks = set()
        newly_confirmed = []
        for point in points:
            dimensions = 3 if len(point) >= 3 else 2
            coordinates = tuple(float(value) for value in point[:dimensions])
            nearest = None
            nearest_distance = float("inf")
            for track in self.tracks:
                if track["id"] in used_tracks or track["dimensions"] != dimensions:
                    continue
                if dimensions == 3 and abs(coordinates[2] - track["z"]) > 1.0:
                    continue
                distance = math.hypot(
                    coordinates[0] - track["x"],
                    coordinates[1] - track["y"],
                )
                if distance < nearest_distance:
                    nearest = track
                    nearest_distance = distance
            if nearest is None or nearest_distance > self.merge_radius:
                nearest = {
                    "id": self._next_id,
                    "dimensions": dimensions,
                    "x": coordinates[0],
                    "y": coordinates[1],
                    "count": 1,
                    "confirmed": self.confirm_count <= 1,
                    "metadata": dict(metadata or {}),
                }
                if dimensions == 3:
                    nearest["z"] = coordinates[2]
                self._next_id += 1
                self.tracks.append(nearest)
                if nearest["confirmed"]:
                    newly_confirmed.append(nearest)
                used_tracks.add(nearest["id"])
                continue
            count = nearest["count"] + 1
            nearest["x"] += (coordinates[0] - nearest["x"]) / count
            nearest["y"] += (coordinates[1] - nearest["y"]) / count
            if dimensions == 3:
                nearest["z"] += (coordinates[2] - nearest["z"]) / count
            nearest["count"] = count
            used_tracks.add(nearest["id"])
            if not nearest["confirmed"] and count >= self.confirm_count:
                nearest["confirmed"] = True
                nearest["metadata"] = dict(metadata or {})
                newly_confirmed.append(nearest)
        self.last_newly_confirmed = list(newly_confirmed)
        return self.confirmed()

    def confirmed(self):
        return [
            ((t["x"], t["y"], t["z"])
             if t["dimensions"] == 3 else (t["x"], t["y"]))
            for t in self.tracks if t["count"] >= self.confirm_count
        ]

    def confirmed_tracks(self):
        return [t for t in self.tracks if t["count"] >= self.confirm_count]


def detect_red_spheres(img_rgb, min_area=50, min_fill=0.55, sat_min=60, val_min=60,
                       min_vertices=6, min_circularity=0.74):
    hsv = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2HSV)
    mask = cv2.inRange(hsv, (0, sat_min, val_min), (10, 255, 255)) | \
           cv2.inRange(hsv, (170, sat_min, val_min), (180, 255, 255))
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    detections = []
    for contour in contours:
        area = cv2.contourArea(contour)
        if area < min_area:
            continue
        (ex, ey), radius = cv2.minEnclosingCircle(contour)
        if radius <= 0.0:
            continue
        fill = area / (math.pi * radius * radius)
        if fill < min_fill:
            continue
        perimeter = cv2.arcLength(contour, True)
        circularity = (4.0 * math.pi * area / (perimeter * perimeter)
                       if perimeter > 1e-6 else 0.0)
        vertices = len(cv2.approxPolyDP(contour, 0.04 * perimeter, True))
        # A sphere has a rounded silhouette even when part of it is hidden;
        # boxes and polygonal red distractors have four or five corners.
        if vertices < int(min_vertices) or circularity < float(min_circularity):
            continue
        moments = cv2.moments(contour)
        detections.append((moments["m10"] / area, moments["m01"] / area, radius, fill))
    return detections


def pixel_to_world(cx_px, cy_px, base_xyz_world, base_yaw_world, calibration=None):
    calibration = calibration or CameraCalibration.front_camera_fallback()
    horizontal = (cx_px - calibration.cx) / calibration.fx
    vertical = -(cy_px - calibration.cy) / calibration.fy
    ray_camera = np.array([1.0, -horizontal, vertical], dtype=float)

    cp = math.cos(calibration.pitch)
    sp = math.sin(calibration.pitch)
    pitch_rotation = np.array([[cp, 0.0, sp], [0.0, 1.0, 0.0], [-sp, 0.0, cp]])
    ray_base = pitch_rotation @ ray_camera

    cyaw = math.cos(base_yaw_world)
    syaw = math.sin(base_yaw_world)
    yaw_rotation = np.array([[cyaw, -syaw, 0.0], [syaw, cyaw, 0.0], [0.0, 0.0, 1.0]])
    ray_world = yaw_rotation @ ray_base
    camera_world = np.asarray(base_xyz_world, dtype=float) + yaw_rotation @ calibration.xyz_base
    if ray_world[2] >= -1e-6:
        return None
    scale = (DANGER_Z - camera_world[2]) / ray_world[2]
    if scale <= 0.0:
        return None
    point = camera_world + scale * ray_world
    return float(point[0]), float(point[1])


def depth_pixel_to_world(cx_px, cy_px, depth, base_xyz_world, base_yaw_world, calibration):
    horizontal = (cx_px - calibration.cx) / calibration.fx
    vertical = -(cy_px - calibration.cy) / calibration.fy
    point_camera = np.array([depth, -horizontal * depth, vertical * depth], dtype=float)
    cp = math.cos(calibration.pitch)
    sp = math.sin(calibration.pitch)
    pitch_rotation = np.array([[cp, 0.0, sp], [0.0, 1.0, 0.0], [-sp, 0.0, cp]])
    point_base = calibration.xyz_base + pitch_rotation @ point_camera
    cyaw = math.cos(base_yaw_world)
    syaw = math.sin(base_yaw_world)
    yaw_rotation = np.array([[cyaw, -syaw, 0.0], [syaw, cyaw, 0.0], [0.0, 0.0, 1.0]])
    point_world = np.asarray(base_xyz_world, dtype=float) + yaw_rotation @ point_base
    return float(point_world[0]), float(point_world[1]), float(point_world[2])


class Detector:
    def __init__(self, out_json, image_topic="/real_sense/rgb/image_raw", odom_topic="/Odometry_gazebo",
                 camera_info_topic="/real_sense/rgb/camera_info",
                 depth_topic="/real_sense/depth/image_raw", use_depth=True):
        import rospy
        import message_filters
        from geometry_msgs.msg import PoseArray
        from nav_msgs.msg import Odometry
        from sensor_msgs.msg import CameraInfo, Image
        from std_msgs.msg import Bool, String

        self.rospy = rospy
        self.Image = Image
        self.Bool = Bool
        self.PoseArray = PoseArray
        self.out_json = out_json
        self.base_xyz = [0.0, 2.0, 0.6]
        self.base_yaw = math.pi / 2.0
        self.pose_samples = deque(maxlen=200)
        self.use_depth = bool(use_depth)
        self.calibration = (
            CameraCalibration.real_sense_fallback() if self.use_depth else
            CameraCalibration.recording_camera_fallback())
        self.latest_depth = None
        self.scan_active = False
        self.scan_label = ""
        self.stage = "algorithm_preparation"
        self.floor = None
        self.waypoint = None
        self.scan_points = []
        self.scan_frame = 0
        self.scan_batches = []
        self._scan_batch = None
        self.scan_merge_radius = float(rospy.get_param("~scan_merge_radius", 1.2))
        self.floor_height = float(rospy.get_param("~floor_height_m", 2.6))
        self.tracker = DetectionTracker(
            rospy.get_param("~merge_radius", 0.75), rospy.get_param("~confirm_count", 3)
        )
        self.start_time = None
        self.started_wall_time = None
        self.exploration_active = False
        self.terminal_status = None
        # rospy subscriber callbacks run on separate threads.  In particular,
        # exploration_active=false and mission_complete=true can arrive
        # together at mission shutdown, so output and terminal-state changes
        # must be serialized.
        self._output_lock = threading.RLock()
        self.frames_processed = 0
        self.frames_with_candidates = 0
        self.detection_events = []
        self.maximum_processing_rate_hz = max(
            0.0, float(rospy.get_param("~maximum_processing_rate_hz", 5.0)))
        self._last_processed_monotonic = None
        self._camera_ready = False
        self.pose_pub = rospy.Publisher("/scanplanner/confirmed_dangers", PoseArray, queue_size=1, latch=True)
        self.debug_pub = rospy.Publisher("/scanplanner/danger_debug_image", Image, queue_size=1)
        self.camera_ready_pub = rospy.Publisher(
            rospy.get_param("~camera_ready_topic", "/simenv/recording_camera_ready"),
            Bool, queue_size=1, latch=True)
        self.camera_ready_pub.publish(self.Bool(data=False))
        rospy.Subscriber(odom_topic, Odometry, self._odom, queue_size=50)
        rospy.Subscriber(camera_info_topic, CameraInfo, self._camera_info, queue_size=1)
        if self.use_depth:
            self.image_sub = message_filters.Subscriber(
                image_topic, Image, queue_size=4, buff_size=2 ** 24)
            self.depth_sub = message_filters.Subscriber(
                depth_topic, Image, queue_size=4, buff_size=2 ** 24)
            self.image_depth_sync = message_filters.ApproximateTimeSynchronizer(
                [self.image_sub, self.depth_sub], queue_size=20, slop=0.15
            )
            self.image_depth_sync.registerCallback(self._synced_image)
        else:
            self.image_sub = rospy.Subscriber(
                image_topic, Image, self._image, queue_size=2,
                buff_size=2 ** 24)
            self.depth_sub = None
            self.image_depth_sync = None
        rospy.Subscriber("/scanplanner/route_failed", Bool, self._terminal, queue_size=1)
        rospy.Subscriber("/simenv/exploration_active", Bool, self._exploration_active_cb, queue_size=2)
        rospy.Subscriber("/scanplanner/three_floor_mission_complete", Bool, self._mission_complete_cb, queue_size=1)
        rospy.Subscriber("/simenv/mission_abort", Bool, self._mission_abort_cb, queue_size=1)
        rospy.Subscriber(
            rospy.get_param(
                "~scan_active_topic", "/scanplanner/room_scan_active"),
            Bool, self._scan_active_cb, queue_size=1)
        rospy.Subscriber("/scanplanner/route_state", String, self._route_state_cb, queue_size=1)
        self._write_output("preparing")
        rospy.on_shutdown(self._on_shutdown)

    def _odom(self, msg):
        p = msg.pose.pose.position
        q = msg.pose.pose.orientation
        self.base_xyz = [p.x, p.y, p.z]
        self.base_yaw = math.atan2(2.0 * (q.w * q.z + q.x * q.y), 1.0 - 2.0 * (q.y * q.y + q.z * q.z))
        stamp = msg.header.stamp.to_sec() if msg.header.stamp.to_sec() > 0.0 else self.rospy.get_time()
        self.pose_samples.append((stamp, tuple(self.base_xyz), self.base_yaw))

    def _camera_info(self, msg):
        self.calibration = CameraCalibration.from_camera_info(msg, self.calibration)

    def _terminal(self, msg):
        if msg.data:
            self._finalize("failed")

    def _exploration_active_cb(self, msg):
        with self._output_lock:
            active = bool(msg.data)
            if active and self.start_time is None:
                self.start_time = time.monotonic()
                self.started_wall_time = time.time()
                self.exploration_active = True
                self.terminal_status = None
                self._write_output("running")
                self.rospy.loginfo(
                    "danger_detector: exploration clock started after preparation")
            elif not active and self.exploration_active:
                # The mission-complete/abort callbacks provide the
                # authoritative terminal status.  Keep a running snapshot only
                # if this Bool wins the race; a terminal status can never be
                # downgraded by a later callback.
                self.exploration_active = False
                self._write_output(self.terminal_status or "running")

    def _mission_complete_cb(self, msg):
        if bool(msg.data):
            self._finalize("completed")

    def _mission_abort_cb(self, msg):
        if bool(msg.data):
            self._finalize("failed")

    def _start_scan_batch(self):
        """Snapshot label/stage/floor at scan start so later route-state
        callbacks cannot relabel a batch that is already being recorded."""
        self._scan_batch = {
            "label": str(self.scan_label),
            "stage": str(self.stage),
            "floor": self.floor,
            "processed_frames": 0,
            "candidate_frames": 0,
        }

    def _record_scan_frame(self, world_points):
        """Count one processed scan frame and its accepted RGB candidates."""
        batch = getattr(self, "_scan_batch", None)
        if batch is None:
            return
        batch["processed_frames"] += 1
        if world_points:
            batch["candidate_frames"] += 1

    def _scan_active_cb(self, msg):
        active = bool(msg.data)
        if active and not self.scan_active:
            self.scan_points = []
            self.scan_frame = 0
            self._start_scan_batch()
        elif not active and self.scan_active:
            batch = getattr(self, "_scan_batch", None)
            if batch is None:
                self._start_scan_batch()
                batch = self._scan_batch
            # The frozen start-of-scan label is authoritative for the whole
            # batch; a route-state relabel mid-scan must not change the
            # evidence threshold or the logged batch identity.
            batch_label = str(batch.get("label", self.scan_label))
            batch_min_points = scan_min_points(batch_label)
            clustered = cluster_scan_points(
                self.scan_points,
                self.scan_merge_radius,
                min_points=batch_min_points,
            )
            diagnostic_clusters = cluster_scan_points(
                self.scan_points,
                self.scan_merge_radius,
                min_points=1,
            )
            self.rospy.loginfo(
                "danger_detector: scan batch label=%s raw=%d min_points=%d clusters=%s",
                batch_label, len(self.scan_points), batch_min_points, clustered,
            )
            # Diagnostic evidence only: the batch clusters are deliberately
            # not fed into DetectionTracker, so confirmation semantics stay
            # untouched.
            batch.update({
                "raw_candidate_points": int(len(self.scan_points)),
                "clustered_candidate_count": int(len(clustered)),
                "minimum_cluster_points": int(batch_min_points),
                "candidate_clusters_min1": [
                    [round(float(x), 4), round(float(y), 4)]
                    for x, y in diagnostic_clusters
                ],
                "candidate_clusters_min1_count": int(
                    len(diagnostic_clusters)),
            })
            self.scan_batches.append(dict(batch))
            self._scan_batch = None
            self.scan_points = []
            self._write_output(self.terminal_status or "running")
        self.scan_active = active

    def _route_state_cb(self, msg):
        text = str(msg.data)
        try:
            payload = json.loads(text)
        except (TypeError, ValueError):
            payload = {"phase": text}
        if not isinstance(payload, dict):
            payload = {"phase": text}
        phase = str(payload.get("phase", "unknown"))
        floor = payload.get("floor")
        if phase == "EXPLORATION_STARTED" and self.start_time is None:
            self._exploration_active_cb(type("BoolMessage", (), {"data": True})())
        if phase == "ENTER_MAIN_ENTRANCE_STAIR_RL":
            self.stage = "entrance_step_stair_rl"
            self.floor = 1
        elif phase == "EXPLORE_FLOOR" and floor is not None:
            self.stage = "floor_{}_exploration".format(int(floor))
        elif phase == "RELEASE_TO_STAIR_RL" and floor is not None:
            self.stage = {
                1: "stair_f1_to_f2",
                2: "stair_f2_to_f3",
                3: "stair_f3_to_f1_descent",
            }.get(int(floor), self.stage)
        self.floor = int(floor) if floor is not None else self.floor
        self.waypoint = payload.get("waypoint", self.waypoint)
        self.scan_label = str(payload.get("waypoint", phase))

    def _depth(self, msg):
        if msg.encoding == "32FC1" and len(msg.data) == msg.height * msg.width * 4:
            self.latest_depth = np.frombuffer(msg.data, dtype=np.float32).reshape(msg.height, msg.width).copy()
        elif msg.encoding == "16UC1" and len(msg.data) == msg.height * msg.width * 2:
            self.latest_depth = np.frombuffer(msg.data, dtype=np.uint16).reshape(msg.height, msg.width).astype(float) / 1000.0

    def _synced_image(self, image_msg, depth_msg):
        self._depth(depth_msg)
        self._image(image_msg)

    def _depth_at(self, cx, cy):
        if self.latest_depth is None:
            return None
        x = int(round(cx))
        y = int(round(cy))
        x0, x1 = max(0, x - 2), min(self.latest_depth.shape[1], x + 3)
        y0, y1 = max(0, y - 2), min(self.latest_depth.shape[0], y + 3)
        values = self.latest_depth[y0:y1, x0:x1]
        valid = values[np.isfinite(values) & (values >= 0.4) & (values <= 8.0)]
        return float(np.median(valid)) if valid.size else None

    def _publish_confirmed(self, header):
        from geometry_msgs.msg import Pose

        output = self.PoseArray()
        output.header = header
        output.header.frame_id = "map"
        for point in self.tracker.confirmed():
            pose = Pose()
            pose.position.x = point[0]
            pose.position.y = point[1]
            pose.position.z = point[2] if len(point) >= 3 else DANGER_Z
            pose.orientation.w = 1.0
            output.poses.append(pose)
        self.pose_pub.publish(output)

    def _image(self, msg):
        if msg.encoding not in ("rgb8", "bgr8"):
            return
        expected = msg.height * msg.width * 3
        if len(msg.data) != expected:
            return
        if not self._camera_ready:
            self._camera_ready = True
            self.camera_ready_pub.publish(self.Bool(data=True))
            self.rospy.loginfo(
                "danger_detector: first rendered RGB frame ready (%dx%d)",
                msg.width, msg.height)
        now_monotonic = time.monotonic()
        if (self.maximum_processing_rate_hz > 0.0 and
                self._last_processed_monotonic is not None and
                now_monotonic - self._last_processed_monotonic <
                1.0 / self.maximum_processing_rate_hz):
            return
        self._last_processed_monotonic = now_monotonic
        image = np.frombuffer(msg.data, dtype=np.uint8).reshape(msg.height, msg.width, 3)
        rgb = image if msg.encoding == "rgb8" else image[:, :, ::-1]
        candidates = detect_red_spheres(rgb)
        stamp = msg.header.stamp.to_sec() if msg.header.stamp.to_sec() > 0.0 else self.rospy.get_time()
        base_xyz, base_yaw = nearest_pose(
            self.pose_samples, stamp, (tuple(self.base_xyz), self.base_yaw)
        )
        world_points = []
        floor_z = round(float(base_xyz[2]) / self.floor_height) * self.floor_height
        danger_z = floor_z + DANGER_Z
        for cx, cy, radius, _fill in candidates:
            depth = select_sphere_depth(self._depth_at(cx, cy), radius, self.calibration.fx)
            if depth is not None:
                point3 = depth_pixel_to_world(cx, cy, depth, base_xyz, base_yaw, self.calibration)
                world_points.append((point3[0], point3[1], danger_z))
            else:
                point = pixel_to_world(cx, cy, base_xyz, base_yaw, self.calibration)
                if point is not None:
                    world_points.append((point[0], point[1], danger_z))
        if should_update_detections(self.scan_active):
            self.scan_frame += 1
            self.scan_points.extend(
                (point[0], point[1], self.scan_frame) for point in world_points)
            self._record_scan_frame(world_points)
        if self.exploration_active and self.start_time is not None:
            self.frames_processed += 1
            if world_points:
                self.frames_with_candidates += 1
            elapsed = time.monotonic() - self.start_time
            metadata = {
                "first_confirmed_elapsed_sec": round(elapsed, 3),
                "first_confirmed_wall_time": round(time.time(), 3),
                "ros_time": round(float(self.rospy.get_time()), 3),
                "stage": self.stage,
                "floor": self.floor,
                "waypoint": self.waypoint,
                "scan_active": bool(self.scan_active),
            }
            if should_update_detections(self.scan_active):
                self.tracker.update(world_points, metadata=metadata)
            else:
                # A direct-RL navigation command also uses scan_cmd_vel, but
                # only the dedicated stationary-room-scan topic is detection
                # evidence.  Clear the edge-trigger list when tracking is
                # intentionally paused so confirmations cannot be replayed.
                self.tracker.last_newly_confirmed = []
            for track in self.tracker.last_newly_confirmed:
                event = dict(track.get("metadata", {}))
                event.update({
                    "track_id": int(track["id"]),
                    "position": [round(track["x"], 4),
                                 round(track["y"], 4),
                                 round(track.get("z", danger_z), 4)],
                    "confirmation_frames": int(track["count"]),
                })
                self.detection_events.append(event)
                self.rospy.loginfo(
                    "danger_detector: confirmed red sphere #%d at %s, t=%.2fs, stage=%s",
                    track["id"], event["position"], elapsed, self.stage)
            if self.tracker.last_newly_confirmed or self.frames_processed % 25 == 0:
                self._write_output("running")
        confirmed = self.tracker.confirmed()
        self._publish_confirmed(msg.header)

        if self.debug_pub.get_num_connections() > 0:
            debug = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
            for cx, cy, radius, _fill in candidates:
                cv2.circle(
                    debug, (int(round(cx)), int(round(cy))),
                    int(round(radius)), (0, 255, 255), 2)
            elapsed = (time.monotonic() - self.start_time
                       if self.start_time is not None else 0.0)
            cv2.putText(
                debug, "detected=%d  elapsed=%.1fs" % (len(confirmed), elapsed),
                (18, 34), cv2.FONT_HERSHEY_SIMPLEX, 0.8,
                (255, 255, 255), 2, cv2.LINE_AA)
            out = self.Image()
            out.header = msg.header
            out.height, out.width = debug.shape[:2]
            out.encoding = "bgr8"
            out.is_bigendian = False
            out.step = out.width * 3
            out.data = debug.tobytes()
            self.debug_pub.publish(out)

    def _write_output(self, status):
        with self._output_lock:
            # Once a terminal callback has won, no delayed running/preparing
            # callback may overwrite the terminal evidence file.
            effective_status = self.terminal_status or str(status)
            elapsed = (time.monotonic() - self.start_time
                       if self.start_time is not None else None)
            events_by_id = {
                int(event["track_id"]): event for event in self.detection_events
            }
            detections = []
            for track in self.tracker.confirmed_tracks():
                event = dict(events_by_id.get(int(track["id"]), {}))
                event.update({
                    "track_id": int(track["id"]),
                    "position": [round(track["x"], 4), round(track["y"], 4),
                                 round(track.get("z", DANGER_Z), 4)],
                    "evidence_frames": int(track["count"]),
                })
                detections.append(event)
            output = {
                "schema": "scanplanner_red_ball_detections_v1",
                "status": str(effective_status),
                "preparation_excluded": True,
                "clock_definition": "wall monotonic time from EXPLORATION_STARTED",
                "exploration_started_wall_time": (
                    round(self.started_wall_time, 3)
                    if self.started_wall_time is not None else None),
                "exploration_duration_sec": (
                    round(elapsed, 3) if elapsed is not None else None),
                "frames_processed": int(self.frames_processed),
                "frames_with_red_sphere_candidates": int(self.frames_with_candidates),
                "confirmed_count": len(detections),
                "detections": detections,
                "scan_batches": [dict(batch) for batch in
                                 getattr(self, "scan_batches", [])],
            }
            directory = os.path.dirname(self.out_json) or "."
            os.makedirs(directory, exist_ok=True)
            temporary = "%s.tmp.%d.%d" % (
                self.out_json, os.getpid(), threading.get_ident())
            try:
                with open(temporary, "w", encoding="utf-8") as stream:
                    json.dump(output, stream, ensure_ascii=False, indent=2,
                              sort_keys=True)
                    stream.write("\n")
                os.replace(temporary, self.out_json)
            finally:
                if os.path.exists(temporary):
                    os.unlink(temporary)

    def _finalize(self, status):
        with self._output_lock:
            if self.terminal_status is not None:
                return
            if self.scan_active:
                self._scan_active_cb(type("BoolMessage", (), {"data": False})())
            self.terminal_status = str(status)
            self.exploration_active = False
            self._write_output(status)
            self.rospy.loginfo(
                "danger_detector: wrote %d confirmed red-ball detections -> %s",
                len(self.tracker.confirmed()), self.out_json)

    def _on_shutdown(self):
        if self.terminal_status is None:
            self._finalize("interrupted")


def _selftest():
    image = np.zeros((800, 800, 3), np.uint8)
    cv2.circle(image, (500, 400), 45, (255, 0, 0), -1)
    cv2.rectangle(image, (120, 120), (210, 210), (255, 0, 0), -1)
    detections = detect_red_spheres(image)
    calibration = CameraCalibration.front_camera_fallback()
    projected = pixel_to_world(calibration.cx, calibration.cy, [0.0, 2.0, 0.6], math.pi / 2.0, calibration)
    ok = len(detections) == 1 and projected is not None and abs(projected[1] - 3.45) < 0.15
    print("detect=%d projected=%s" % (len(detections), projected))
    print("SELFCHECK:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        raise SystemExit(_selftest())
    import rospy

    rospy.init_node("danger_detector", anonymous=False)
    output_path = rospy.get_param("~out_json", "/workspace/SimEnv/results/detected_danger.json")
    Detector(
        output_path,
        rospy.get_param("~image_topic", "/real_sense/rgb/image_raw"),
        camera_info_topic=rospy.get_param("~camera_info_topic", "/real_sense/rgb/camera_info"),
        depth_topic=rospy.get_param("~depth_topic", "/real_sense/depth/image_raw"),
        use_depth=rospy.get_param("~use_depth", True),
    )
    rospy.spin()
