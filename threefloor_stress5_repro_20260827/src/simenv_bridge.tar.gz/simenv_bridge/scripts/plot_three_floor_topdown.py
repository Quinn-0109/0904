#!/usr/bin/env python3
"""Render one top-down executed-route plot for each mission floor."""

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle


FLOOR_TOUR_FILES = (
    "tour_summary.json",
    "second_floor/tour_summary.json",
    "third_floor/tour_summary.json",
)


def read_json(path, required=True):
    path = Path(path)
    if not path.is_file():
        if required:
            raise FileNotFoundError(path)
        return {}
    with path.open("r", encoding="utf-8") as stream:
        return json.load(stream)


def bounds_rectangle(bounds, **kwargs):
    return Rectangle(
        (float(bounds["x_min"]), float(bounds["y_min"])),
        float(bounds["x_max"]) - float(bounds["x_min"]),
        float(bounds["y_max"]) - float(bounds["y_min"]),
        **kwargs,
    )


def waypoint_xy(tour):
    points = []
    for waypoint in tour.get("waypoints", []):
        pose = waypoint.get("reached_pose")
        if isinstance(pose, list) and len(pose) >= 2:
            points.append((float(pose[0]), float(pose[1]), waypoint))
    return points


def trace_xy(payload, segment=None):
    points = []
    for sample in payload.get("trace", []):
        if segment is not None and int(sample.get("segment", -1)) != segment:
            continue
        if sample.get("x") is None or sample.get("y") is None:
            continue
        points.append((float(sample["x"]), float(sample["y"])))
    return points


def plot_polyline(ax, points, color, label, linewidth=2.2, alpha=0.95,
                  linestyle="-"):
    if len(points) < 2:
        return
    ax.plot(
        [point[0] for point in points],
        [point[1] for point in points],
        color=color,
        linewidth=linewidth,
        alpha=alpha,
        linestyle=linestyle,
        solid_capstyle="round",
        label=label,
        zorder=7,
    )


def stage_duration(stage_timing, name):
    for stage in stage_timing.get("stages", []):
        if stage.get("name") == name:
            return stage.get("duration_sec")
    return None


def draw_layout(ax, floor):
    footprint = {
        "x_min": -10.0,
        "x_max": 10.0,
        "y_min": 0.0,
        "y_max": 36.0,
    }
    ax.add_patch(bounds_rectangle(
        footprint, facecolor="#fafafa", edgecolor="#111827",
        linewidth=2.0, zorder=0))
    ax.add_patch(bounds_rectangle(
        floor["lobby_bounds"], facecolor="#dbeafe", edgecolor="#64748b",
        linewidth=1.1, zorder=1))
    ax.add_patch(bounds_rectangle(
        floor["corridor_bounds"], facecolor="#e5e7eb", edgecolor="#64748b",
        linewidth=1.1, zorder=1))

    room_colors = ("#fef3c7", "#dcfce7", "#ffedd5", "#f3e8ff")
    for room_index, room in enumerate(floor.get("rooms", [])):
        ax.add_patch(bounds_rectangle(
            room["bounds"], facecolor=room_colors[room_index % 4],
            edgecolor="#475569", linewidth=1.0, alpha=0.72, zorder=1))
        bounds = room["bounds"]
        x = (float(bounds["x_min"]) + float(bounds["x_max"])) / 2.0
        y = (float(bounds["y_min"]) + float(bounds["y_max"])) / 2.0
        room_type = str(room.get("room_type", "room")).replace("_", " ")
        ax.text(
            x, y, "Room {}\n{}".format(room_index + 1, room_type),
            ha="center", va="center", color="#475569", fontsize=8,
            alpha=0.85, zorder=2)

    stair = floor.get("stair_bounds")
    if stair:
        ax.add_patch(bounds_rectangle(
            stair, facecolor="#fed7aa", edgecolor="#c2410c",
            linewidth=1.3, hatch="////", alpha=0.7, zorder=2))
        ax.text(
            (stair["x_min"] + stair["x_max"]) / 2.0,
            (stair["y_min"] + stair["y_max"]) / 2.0,
            "STAIRS", ha="center", va="center", fontsize=7,
            color="#9a3412", rotation=90, zorder=3)
    elevator = floor.get("elevator_bounds")
    if elevator:
        ax.add_patch(bounds_rectangle(
            elevator, facecolor="#cbd5e1", edgecolor="#475569",
            linewidth=1.0, hatch="xx", alpha=0.75, zorder=2))
        ax.text(
            (elevator["x_min"] + elevator["x_max"]) / 2.0,
            (elevator["y_min"] + elevator["y_max"]) / 2.0,
            "LIFT\n(not used)", ha="center", va="center", fontsize=6,
            color="#475569", zorder=3)


def draw_floor(ax, floor_index, layout, tours, red_record, mission,
               timing, ascent_traces, descent_trace):
    floor = layout["floors"][floor_index]
    tour_points = waypoint_xy(tours[floor_index])
    draw_layout(ax, floor)

    plane_points = [(x, y) for x, y, _waypoint in tour_points]
    if floor_index == 0 and len(plane_points) >= 3:
        spawn = timing.get("spawn_truth_pose_at_start") or [0.0, -3.2]
        entrance_points = [(float(spawn[0]), float(spawn[1]))] + plane_points[:3]
        plot_polyline(
            ax, entrance_points, "#ea580c", "stair RL (entrance)",
            linewidth=2.8)
        plane_points = plane_points[2:]
    elif floor_index > 0 and ascent_traces[floor_index - 1]:
        plane_points = [ascent_traces[floor_index - 1][-1]] + plane_points

    plot_polyline(ax, plane_points, "#2563eb", "plane RL", linewidth=2.5)

    if floor_index < 2:
        plot_polyline(
            ax, ascent_traces[floor_index], "#ea580c", "stair RL (up)",
            linewidth=2.6)

    descent_segment = 0 if floor_index == 2 else (1 if floor_index == 1 else None)
    if floor_index == 2:
        down_points = trace_xy(descent_trace, segment=0)
    elif floor_index == 1:
        # Show both the upper arrival and lower departure around the F2 landing.
        down_points = trace_xy(descent_trace, segment=0) + trace_xy(
            descent_trace, segment=1)
    else:
        down_points = trace_xy(descent_trace, segment=1)
    plot_polyline(
        ax, down_points, "#7c3aed", "stair RL (down)", linewidth=2.2,
        alpha=0.85)

    if floor_index == 0:
        returned = []
        down_all = trace_xy(descent_trace)
        if down_all:
            returned.append(down_all[-1])
        for waypoint in mission.get("return_waypoints", []):
            pose = waypoint.get("reached_pose")
            if isinstance(pose, list) and len(pose) >= 2:
                returned.append((float(pose[0]), float(pose[1])))
        plot_polyline(
            ax, returned, "#059669", "plane RL (lobby return)",
            linewidth=2.8)

    if tour_points:
        ax.scatter(
            [point[0] for point in tour_points],
            [point[1] for point in tour_points],
            s=18, facecolor="white", edgecolor="#1d4ed8", linewidth=0.9,
            zorder=9)
        for order, (x, y, waypoint) in enumerate(tour_points, start=1):
            ax.annotate(
                str(order), (x, y), xytext=(3, 3), textcoords="offset points",
                fontsize=5.5, color="#1e3a8a", zorder=10)
            if waypoint.get("scan_completed"):
                ax.scatter(
                    [x], [y], marker="*", s=75, facecolor="#06b6d4",
                    edgecolor="#164e63", linewidth=0.7, zorder=10)

    detections = [
        item for item in red_record.get("detections", [])
        if int(item.get("floor", -1)) == floor_index + 1
    ]
    if detections:
        ax.scatter(
            [item["position"][0] for item in detections],
            [item["position"][1] for item in detections],
            marker="o", s=42, facecolor="#ef4444", edgecolor="#7f1d1d",
            linewidth=0.8, zorder=11, label="RGB red-ball confirmation")

    duration = stage_duration(timing, "floor_{}_exploration".format(floor_index + 1))
    duration_text = "{:.2f} s".format(float(duration)) if duration is not None else "running"
    ax.set_title(
        "Floor {} top-down executed route\nexploration={} | RGB confirmations={}".format(
            floor_index + 1, duration_text, len(detections)),
        fontsize=11, fontweight="bold")
    ax.set_xlim(-10.7, 10.7)
    ax.set_ylim(-3.8 if floor_index == 0 else -0.7, 36.6)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("world x (m)")
    ax.set_ylabel("world y (m)")
    ax.grid(True, color="#94a3b8", alpha=0.22, linewidth=0.6)
    ax.text(
        0.01, 0.01,
        "Lines connect actual reached poses; stair traces are dense Gazebo truth.",
        transform=ax.transAxes, fontsize=6.5, color="#475569",
        ha="left", va="bottom",
        bbox={"boxstyle": "round,pad=0.25", "facecolor": "white", "alpha": 0.8,
              "edgecolor": "#cbd5e1"})
    handles = [
        Line2D([0], [0], color="#2563eb", lw=2.5, label="plane RL"),
        Line2D([0], [0], color="#ea580c", lw=2.6, label="stair RL up/entrance"),
        Line2D([0], [0], color="#7c3aed", lw=2.2, label="stair RL down"),
        Line2D([0], [0], marker="*", color="none", markerfacecolor="#06b6d4",
               markeredgecolor="#164e63", markersize=9, label="room scan pose"),
        Line2D([0], [0], marker="o", color="none", markerfacecolor="#ef4444",
               markeredgecolor="#7f1d1d", markersize=6,
               label="RGB red-ball confirmation"),
    ]
    if floor_index == 0:
        handles.insert(3, Line2D(
            [0], [0], color="#059669", lw=2.8, label="lobby return"))
    ax.legend(handles=handles, loc="upper right", fontsize=6.8, framealpha=0.92)


def generate(results_dir, output_dir):
    results_dir = Path(results_dir).resolve()
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    layout = read_json(results_dir / "layout_metadata.json")
    tours = [read_json(results_dir / relative) for relative in FLOOR_TOUR_FILES]
    red_record = read_json(results_dir / "red_ball_detections.json")
    mission = read_json(results_dir / "three_floor_rl_mission_summary.json")
    timing = read_json(results_dir / "mission_stage_timing.json")
    ascent_traces = [
        trace_xy(read_json(results_dir / "logs/stair_transition.json")),
        trace_xy(read_json(
            results_dir / "logs/second_to_third_floor_stair_transition.json")),
    ]
    descent_trace = read_json(results_dir / "logs/stair_descent.json")

    outputs = []
    for floor_index in range(3):
        figure, axis = plt.subplots(figsize=(7.2, 11.2))
        draw_floor(
            axis, floor_index, layout, tours, red_record, mission, timing,
            ascent_traces, descent_trace)
        figure.tight_layout()
        path = output_dir / "topdown_floor_{}.png".format(floor_index + 1)
        figure.savefig(path, dpi=190, bbox_inches="tight", facecolor="white")
        plt.close(figure)
        outputs.append(path)

    figure, axes = plt.subplots(1, 3, figsize=(19.5, 11.2), sharex=True)
    for floor_index, axis in enumerate(axes):
        draw_floor(
            axis, floor_index, layout, tours, red_record, mission, timing,
            ascent_traces, descent_trace)
    total = timing.get("total_duration_sec")
    figure.suptitle(
        "Three-floor RL exploration — {} — total={} s".format(
            results_dir.name,
            "{:.2f}".format(float(total)) if total is not None else "running"),
        fontsize=14, fontweight="bold", y=0.995)
    figure.tight_layout(rect=(0.0, 0.0, 1.0, 0.98))
    combined = output_dir / "three_floor_topdown_trajectories.png"
    figure.savefig(combined, dpi=180, bbox_inches="tight", facecolor="white")
    plt.close(figure)
    outputs.append(combined)

    manifest = {
        "schema": "scanplanner_three_floor_topdown_v1",
        "results_dir": str(results_dir),
        "source_status": timing.get("status"),
        "source_total_duration_sec": timing.get("total_duration_sec"),
        "source_red_record_status": red_record.get("status"),
        "source_red_confirmed_count": red_record.get("confirmed_count"),
        "plots": [str(path) for path in outputs],
    }
    manifest_path = output_dir / "three_floor_topdown_manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return outputs, manifest_path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", required=True, help="completed mission result directory")
    parser.add_argument("--output-dir", default=None)
    args = parser.parse_args()
    results = Path(args.results)
    output = Path(args.output_dir) if args.output_dir else results / "visualization"
    outputs, manifest = generate(results, output)
    for path in outputs:
        print(path)
    print(manifest)


if __name__ == "__main__":
    main()
